const mongoose = require('mongoose');

const DeviceSchema = new mongoose.Schema({
  deviceId: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  deviceName: {
    type: String,
    required: true,
    trim: true
  },
  deviceModel: {
    type: String,
    trim: true
  },
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'locked', 'maintenance'],
    default: 'active'
  },
  lastConnection: {
    type: Date
  },
  installedApps: [{
    appName: String,
    packageName: String,
    version: String,
    installedDate: Date
  }],
  systemInfo: {
    androidVersion: String,
    sdkVersion: Number,
    manufacturer: String,
    model: String,
    screenResolution: String
  },
  permissions: {
    adminAccess: {
      type: Boolean,
      default: false
    },
    kioskMode: {
      type: Boolean,
      default: false
    },
    remoteControl: {
      type: Boolean,
      default: false
    }
  },
  location: {
    latitude: Number,
    longitude: Number,
    lastUpdated: Date
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// قبل التحديث: تحديث وقت التعديل
DeviceSchema.pre('findOneAndUpdate', function(next) {
  this.set({ updatedAt: Date.now() });
  next();
});

module.exports = mongoose.model('Device', DeviceSchema);