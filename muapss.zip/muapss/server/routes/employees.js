const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Device = require('../models/Device');

// الحصول على جميع الموظفين
router.get('/', async (req, res) => {
  try {
    const employees = await User.find({ role: 'employee' }).select('-password');
    res.json(employees);
  } catch (error) {
    console.error('خطأ في جلب الموظفين:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// الحصول على موظف محدد
router.get('/:id', async (req, res) => {
  try {
    const employee = await User.findById(req.params.id).select('-password');
    if (!employee) {
      return res.status(404).json({ message: 'الموظف غير موجود' });
    }
    res.json(employee);
  } catch (error) {
    console.error('خطأ في جلب الموظف:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// إنشاء موظف جديد
router.post('/', async (req, res) => {
  try {
    const { username, email, password, department } = req.body;

    // التحقق من وجود المستخدم
    const existingUser = await User.findOne({ $or: [{ email }, { username }] });
    if (existingUser) {
      return res.status(400).json({ message: 'اسم المستخدم أو البريد الإلكتروني مستخدم بالفعل' });
    }

    // إنشاء موظف جديد
    const newEmployee = new User({
      username,
      email,
      password,
      role: 'employee',
      department
    });

    await newEmployee.save();

    res.status(201).json({
      message: 'تم إنشاء الموظف بنجاح',
      employee: {
        id: newEmployee._id,
        username: newEmployee.username,
        email: newEmployee.email,
        department: newEmployee.department
      }
    });
  } catch (error) {
    console.error('خطأ في إنشاء الموظف:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// تحديث موظف
router.put('/:id', async (req, res) => {
  try {
    const { username, email, department, isActive } = req.body;

    // التحقق من وجود المستخدم
    const employee = await User.findById(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: 'الموظف غير موجود' });
    }

    // تحديث بيانات الموظف
    employee.username = username || employee.username;
    employee.email = email || employee.email;
    employee.department = department || employee.department;
    employee.isActive = isActive !== undefined ? isActive : employee.isActive;
    employee.updatedAt = Date.now();

    await employee.save();

    res.json({
      message: 'تم تحديث الموظف بنجاح',
      employee: {
        id: employee._id,
        username: employee.username,
        email: employee.email,
        department: employee.department,
        isActive: employee.isActive
      }
    });
  } catch (error) {
    console.error('خطأ في تحديث الموظف:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// حذف موظف
router.delete('/:id', async (req, res) => {
  try {
    const employee = await User.findById(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: 'الموظف غير موجود' });
    }

    // تحديث الأجهزة المرتبطة بالموظف
    await Device.updateMany(
      { assignedTo: req.params.id },
      { $unset: { assignedTo: 1 } }
    );

    await User.findByIdAndDelete(req.params.id);

    res.json({ message: 'تم حذف الموظف بنجاح' });
  } catch (error) {
    console.error('خطأ في حذف الموظف:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// الحصول على أجهزة الموظف
router.get('/:id/devices', async (req, res) => {
  try {
    const devices = await Device.find({ assignedTo: req.params.id });
    res.json(devices);
  } catch (error) {
    console.error('خطأ في جلب أجهزة الموظف:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

module.exports = router;