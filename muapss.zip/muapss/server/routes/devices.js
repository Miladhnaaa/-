const express = require('express');
const router = express.Router();
const Device = require('../models/Device');
const User = require('../models/User');

// الحصول على جميع الأجهزة
router.get('/', async (req, res) => {
  try {
    const devices = await Device.find().populate('assignedTo', 'username email department');
    res.json(devices);
  } catch (error) {
    console.error('خطأ في جلب الأجهزة:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// الحصول على جهاز محدد
router.get('/:id', async (req, res) => {
  try {
    const device = await Device.findById(req.params.id).populate('assignedTo', 'username email department');
    if (!device) {
      return res.status(404).json({ message: 'الجهاز غير موجود' });
    }
    res.json(device);
  } catch (error) {
    console.error('خطأ في جلب الجهاز:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// إضافة جهاز جديد
router.post('/', async (req, res) => {
  try {
    const { deviceId, deviceName, deviceModel, assignedTo } = req.body;

    // التحقق من وجود الجهاز
    const existingDevice = await Device.findOne({ deviceId });
    if (existingDevice) {
      return res.status(400).json({ message: 'معرف الجهاز مستخدم بالفعل' });
    }

    // التحقق من وجود الموظف إذا تم تعيينه
    if (assignedTo) {
      const employee = await User.findById(assignedTo);
      if (!employee) {
        return res.status(404).json({ message: 'الموظف غير موجود' });
      }
    }

    // إنشاء جهاز جديد
    const newDevice = new Device({
      deviceId,
      deviceName,
      deviceModel,
      assignedTo
    });

    await newDevice.save();

    res.status(201).json({
      message: 'تم إضافة الجهاز بنجاح',
      device: newDevice
    });
  } catch (error) {
    console.error('خطأ في إضافة الجهاز:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// تحديث جهاز
router.put('/:id', async (req, res) => {
  try {
    const { deviceName, deviceModel, assignedTo, status, permissions } = req.body;

    // التحقق من وجود الجهاز
    const device = await Device.findById(req.params.id);
    if (!device) {
      return res.status(404).json({ message: 'الجهاز غير موجود' });
    }

    // التحقق من وجود الموظف إذا تم تعيينه
    if (assignedTo) {
      const employee = await User.findById(assignedTo);
      if (!employee) {
        return res.status(404).json({ message: 'الموظف غير موجود' });
      }
    }

    // تحديث بيانات الجهاز
    device.deviceName = deviceName || device.deviceName;
    device.deviceModel = deviceModel || device.deviceModel;
    device.assignedTo = assignedTo || device.assignedTo;
    device.status = status || device.status;
    
    if (permissions) {
      device.permissions = {
        ...device.permissions,
        ...permissions
      };
    }
    
    device.updatedAt = Date.now();

    await device.save();

    res.json({
      message: 'تم تحديث الجهاز بنجاح',
      device
    });
  } catch (error) {
    console.error('خطأ في تحديث الجهاز:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// حذف جهاز
router.delete('/:id', async (req, res) => {
  try {
    const device = await Device.findById(req.params.id);
    if (!device) {
      return res.status(404).json({ message: 'الجهاز غير موجود' });
    }

    await Device.findByIdAndDelete(req.params.id);

    res.json({ message: 'تم حذف الجهاز بنجاح' });
  } catch (error) {
    console.error('خطأ في حذف الجهاز:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// إرسال أمر إلى الجهاز
router.post('/:id/command', async (req, res) => {
  try {
    const { command, params } = req.body;

    // التحقق من وجود الجهاز
    const device = await Device.findById(req.params.id);
    if (!device) {
      return res.status(404).json({ message: 'الجهاز غير موجود' });
    }

    // هنا يمكن إضافة منطق لإرسال الأمر إلى الجهاز عبر Socket.IO
    // سيتم تنفيذ ذلك في ملف server.js

    res.json({
      message: 'تم إرسال الأمر بنجاح',
      deviceId: device.deviceId,
      command,
      params
    });
  } catch (error) {
    console.error('خطأ في إرسال الأمر:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

module.exports = router;