const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// مسار تسجيل مستخدم جديد
router.post('/register', async (req, res) => {
  try {
    const { username, email, password, role, department } = req.body;

    // التحقق من وجود المستخدم
    const existingUser = await User.findOne({ $or: [{ email }, { username }] });
    if (existingUser) {
      return res.status(400).json({ message: 'اسم المستخدم أو البريد الإلكتروني مستخدم بالفعل' });
    }

    // إنشاء مستخدم جديد
    const newUser = new User({
      username,
      email,
      password,
      role,
      department
    });

    await newUser.save();

    // إنشاء رمز JWT
    const token = jwt.sign(
      { id: newUser._id, role: newUser.role },
      process.env.JWT_SECRET,
      { expiresIn: '1d' }
    );

    res.status(201).json({
      message: 'تم إنشاء المستخدم بنجاح',
      token,
      user: {
        id: newUser._id,
        username: newUser.username,
        email: newUser.email,
        role: newUser.role,
        department: newUser.department
      }
    });
  } catch (error) {
    console.error('خطأ في تسجيل المستخدم:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// مسار تسجيل الدخول
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    // البحث عن المستخدم
    const user = await User.findOne({ $or: [{ username }, { email: username }] });
    if (!user) {
      return res.status(401).json({ message: 'بيانات الاعتماد غير صحيحة' });
    }

    // التحقق من كلمة المرور
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: 'بيانات الاعتماد غير صحيحة' });
    }

    // التحقق من حالة المستخدم
    if (!user.isActive) {
      return res.status(401).json({ message: 'تم تعطيل الحساب. يرجى الاتصال بالمسؤول' });
    }

    // تحديث آخر تسجيل دخول
    user.lastLogin = Date.now();
    await user.save();

    // إنشاء رمز JWT
    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '1d' }
    );

    res.json({
      message: 'تم تسجيل الدخول بنجاح',
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        department: user.department,
        twoFactorEnabled: user.twoFactorEnabled
      }
    });
  } catch (error) {
    console.error('خطأ في تسجيل الدخول:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// مسار التحقق من الرمز المميز
router.get('/verify', async (req, res) => {
  try {
    const token = req.header('x-auth-token');
    if (!token) {
      return res.status(401).json({ message: 'لا يوجد رمز مميز، تم رفض الوصول' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('-password');

    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }

    res.json({
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        department: user.department,
        twoFactorEnabled: user.twoFactorEnabled
      }
    });
  } catch (error) {
    console.error('خطأ في التحقق من الرمز المميز:', error);
    res.status(401).json({ message: 'الرمز المميز غير صالح' });
  }
});

module.exports = router;