const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');

// تحميل المتغيرات البيئية
dotenv.config();

// إنشاء تطبيق Express
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// الإعدادات الأساسية
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// تكوين قاعدة البيانات
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/muapss';
mongoose.connect(MONGO_URI)
  .then(() => console.log('تم الاتصال بقاعدة البيانات MongoDB'))
  .catch(err => console.error('خطأ في الاتصال بقاعدة البيانات:', err));

// مسارات API
app.use('/api/auth', require('./routes/auth'));
app.use('/api/employees', require('./routes/employees'));
app.use('/api/devices', require('./routes/devices'));
app.use('/api/apk-builder', require('./routes/apkBuilder'));

// middleware للمصادقة
const { auth, checkRole } = require('./middleware/auth');

// مسارات محمية
app.use('/api/employees', auth, checkRole(['admin', 'manager']));
app.use('/api/devices', auth);
app.use('/api/apk-builder', auth, checkRole(['admin']));


// إعداد Socket.IO للاتصال المباشر مع الأجهزة
io.on('connection', (socket) => {
  console.log('جهاز جديد متصل:', socket.id);

  // استماع لأحداث من الأجهزة
  socket.on('device_status', (data) => {
    console.log('حالة الجهاز:', data);
    // إرسال البيانات إلى لوحة التحكم
    io.emit('admin_device_update', data);
  });

  // استماع للأوامر من لوحة التحكم
  socket.on('admin_command', (data) => {
    console.log('أمر من المسؤول:', data);
    // إرسال الأمر إلى الجهاز المحدد
    io.to(data.deviceId).emit('device_command', data.command);
  });

  socket.on('disconnect', () => {
    console.log('انقطع الاتصال بالجهاز:', socket.id);
  });
});

// خدمة الملفات الثابتة في الإنتاج
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../client/build')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/build', 'index.html'));
  });
}

// تشغيل الخادم
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`الخادم يعمل على المنفذ ${PORT}`);
});