const jwt = require('jsonwebtoken');
const User = require('../models/User');

// التحقق من وجود رمز JWT صالح
const auth = async (req, res, next) => {
  try {
    const token = req.header('x-auth-token');
    if (!token) {
      return res.status(401).json({ message: 'لا يوجد رمز مميز، تم رفض الوصول' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('-password');

    if (!user) {
      return res.status(401).json({ message: 'المستخدم غير موجود' });
    }

    if (!user.isActive) {
      return res.status(401).json({ message: 'تم تعطيل الحساب' });
    }

    req.user = user;
    next();
  } catch (error) {
    console.error('خطأ في المصادقة:', error);
    res.status(401).json({ message: 'الرمز المميز غير صالح' });
  }
};

// التحقق من دور المستخدم
const checkRole = (roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: 'غير مصرح به' });
    }

    const hasRole = roles.includes(req.user.role);
    if (!hasRole) {
      return res.status(403).json({ message: 'ليس لديك صلاحية للوصول إلى هذا المورد' });
    }

    next();
  };
};

module.exports = { auth, checkRole };