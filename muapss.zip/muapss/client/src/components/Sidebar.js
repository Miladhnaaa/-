import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Typography,
  makeStyles,
  Avatar,
  Hidden,
} from '@material-ui/core';
import {
  Dashboard as DashboardIcon,
  People as PeopleIcon,
  PhoneAndroid as DevicesIcon,
  Build as BuildIcon,
  Settings as SettingsIcon,
  ExitToApp as LogoutIcon,
  PhoneAndroid as PhoneAndroidIcon,
} from '@material-ui/icons';

const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  drawer: {
    [theme.breakpoints.up('sm')]: {
      width: drawerWidth,
      flexShrink: 0,
    },
  },
  drawerPaper: {
    width: drawerWidth,
    backgroundColor: theme.palette.background.default,
    borderLeft: `1px solid ${theme.palette.divider}`,
    borderRight: 'none',
  },
  toolbar: theme.mixins.toolbar,
  logo: {
    display: 'flex',
    alignItems: 'center',
    padding: theme.spacing(2),
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.primary.contrastText,
  },
  logoIcon: {
    marginLeft: theme.spacing(1),
  },
  avatar: {
    backgroundColor: theme.palette.secondary.main,
    width: theme.spacing(5),
    height: theme.spacing(5),
  },
  userInfo: {
    padding: theme.spacing(2),
    display: 'flex',
    alignItems: 'center',
    backgroundColor: theme.palette.background.paper,
  },
  userDetails: {
    marginRight: theme.spacing(2),
  },
  listItem: {
    borderRadius: theme.shape.borderRadius,
    margin: theme.spacing(0.5, 1),
    '&.active': {
      backgroundColor: theme.palette.action.selected,
      '& .MuiListItemIcon-root': {
        color: theme.palette.primary.main,
      },
    },
  },
  listItemIcon: {
    minWidth: 40,
  },
  divider: {
    margin: theme.spacing(2, 0),
  },
}));

const Sidebar = ({ mobileOpen, handleDrawerToggle }) => {
  const classes = useStyles();
  const location = useLocation();
  
  // بيانات المستخدم الوهمية - سيتم استبدالها بالبيانات الفعلية من الخادم
  const user = {
    name: 'أحمد محمد',
    role: 'مدير النظام',
    avatar: null, // يمكن استبدالها برابط صورة
  };

  // قائمة عناصر القائمة الجانبية
  const menuItems = [
    { text: 'لوحة التحكم', icon: <DashboardIcon />, path: '/dashboard' },
    { text: 'الموظفون', icon: <PeopleIcon />, path: '/employees' },
    { text: 'الأجهزة', icon: <DevicesIcon />, path: '/devices' },
    { text: 'مولّد التطبيقات', icon: <BuildIcon />, path: '/apk-builder' },
    { text: 'الإعدادات', icon: <SettingsIcon />, path: '/settings' },
  ];

  // محتوى القائمة الجانبية
  const drawer = (
    <div>
      <div className={classes.logo}>
        <Typography variant="h6" noWrap>
          نظام إدارة الموظفين
        </Typography>
        <PhoneAndroidIcon className={classes.logoIcon} />
      </div>
      
      <div className={classes.userInfo}>
        <Avatar className={classes.avatar}>
          {user.name.charAt(0)}
        </Avatar>
        <div className={classes.userDetails}>
          <Typography variant="subtitle2">{user.name}</Typography>
          <Typography variant="body2" color="textSecondary">{user.role}</Typography>
        </div>
      </div>
      
      <List>
        {menuItems.map((item) => (
          <ListItem
            button
            component={Link}
            to={item.path}
            key={item.text}
            className={`${classes.listItem} ${location.pathname === item.path ? 'active' : ''}`}
          >
            <ListItemIcon className={classes.listItemIcon}>{item.icon}</ListItemIcon>
            <ListItemText primary={item.text} />
          </ListItem>
        ))}
      </List>
      
      <Divider className={classes.divider} />
      
      <List>
        <ListItem button className={classes.listItem} onClick={() => {
          localStorage.removeItem('token');
          window.location.href = '/login';
        }}>
          <ListItemIcon className={classes.listItemIcon}>
            <LogoutIcon />
          </ListItemIcon>
          <ListItemText primary="تسجيل الخروج" />
        </ListItem>
      </List>
    </div>
  );

  return (
    <nav className={classes.drawer}>
      {/* القائمة الجانبية للأجهزة المحمولة */}
      <Hidden smUp implementation="css">
        <Drawer
          variant="temporary"
          anchor="right"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          classes={{
            paper: classes.drawerPaper,
          }}
          ModalProps={{
            keepMounted: true, // تحسين الأداء على الأجهزة المحمولة
          }}
        >
          {drawer}
        </Drawer>
      </Hidden>
      
      {/* القائمة الجانبية للأجهزة المكتبية */}
      <Hidden xsDown implementation="css">
        <Drawer
          classes={{
            paper: classes.drawerPaper,
          }}
          variant="permanent"
          anchor="right"
          open
        >
          {drawer}
        </Drawer>
      </Hidden>
    </nav>
  );
};

export default Sidebar;