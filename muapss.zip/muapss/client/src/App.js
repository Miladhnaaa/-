import React from 'react';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@material-ui/core/styles';
import { CssBaseline } from '@material-ui/core';
import { create } from 'jss';
import rtlPlugin from 'jss-rtl';
import { StylesProvider, jssPreset } from '@material-ui/core/styles';

// المكونات
import Layout from './components/Layout';

// صفحات التطبيق
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Employees from './pages/Employees';
import Devices from './pages/Devices';
import ApkBuilder from './pages/ApkBuilder';
import Settings from './pages/Settings';

// إعداد JSS للدعم العربي (RTL)
const jss = create({ plugins: [...jssPreset().plugins, rtlPlugin()] });

// إنشاء سمة التطبيق
const theme = createTheme({
  direction: 'rtl',
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    background: {
      default: '#f5f5f5',
    },
  },
  typography: {
    fontFamily: [
      'Tajawal',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif',
    ].join(','),
  },
});

// مكون التطبيق الرئيسي
function App() {

  return (
    <StylesProvider jss={jss}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <div dir="rtl">
          <Router>
            <Switch>
              <Route exact path="/login" component={Login} />
              <Route path="/">
                <Layout>
                  <Switch>
                    <PrivateRoute exact path="/dashboard" component={Dashboard} />
                    <PrivateRoute exact path="/employees" component={Employees} />
                    <PrivateRoute exact path="/devices" component={Devices} />
                    <PrivateRoute exact path="/apk-builder" component={ApkBuilder} />
                    <PrivateRoute exact path="/settings" component={Settings} />
                    <Redirect from="/" to="/dashboard" />
                  </Switch>
                </Layout>
              </Route>
            </Switch>
          </Router>
        </div>
      </ThemeProvider>
    </StylesProvider>
  );
}

// مكون المسار الخاص (يتطلب المصادقة)
const PrivateRoute = ({ component: Component, ...rest }) => {
  const isAuthenticated = localStorage.getItem('token') !== null;
  
  return (
    <Route
      {...rest}
      render={props =>
        isAuthenticated ? (
          <Component {...props} />
        ) : (
          <Redirect to={{ pathname: '/login', state: { from: props.location } }} />
        )
      }
    />
  );
};

export default App;