import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Paper,
  Typography,
  makeStyles,
  Card,
  CardContent,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Button,
} from '@material-ui/core';
import {
  People as PeopleIcon,
  PhoneAndroid as DevicesIcon,
  Build as BuildIcon,
  Notifications as NotificationsIcon,
  Warning as WarningIcon,
} from '@material-ui/icons';

const useStyles = makeStyles((theme) => ({
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
  },
  paper: {
    padding: theme.spacing(3),
    display: 'flex',
    overflow: 'auto',
    flexDirection: 'column',
  },
  fixedHeight: {
    height: 240,
  },
  statsCard: {
    textAlign: 'center',
    height: '100%',
  },
  statValue: {
    fontSize: '2.5rem',
    fontWeight: 'bold',
    color: theme.palette.primary.main,
    marginBottom: theme.spacing(1),
  },
  statLabel: {
    fontSize: '1.1rem',
    color: theme.palette.text.secondary,
  },
  sectionTitle: {
    marginBottom: theme.spacing(2),
    marginTop: theme.spacing(3),
  },
  alertItem: {
    backgroundColor: theme.palette.error.light,
    marginBottom: theme.spacing(1),
    borderRadius: theme.shape.borderRadius,
  },
  warningItem: {
    backgroundColor: theme.palette.warning.light,
    marginBottom: theme.spacing(1),
    borderRadius: theme.shape.borderRadius,
  },
  activityItem: {
    marginBottom: theme.spacing(1),
    borderBottom: `1px solid ${theme.palette.divider}`,
    '&:last-child': {
      borderBottom: 'none',
    },
  },
  divider: {
    margin: theme.spacing(2, 0),
  },
  actionButton: {
    marginTop: theme.spacing(2),
  },
}));

const Dashboard = () => {
  const classes = useStyles();
  const [stats, setStats] = useState({
    employees: 0,
    devices: 0,
    apkBuilds: 0,
    alerts: 0,
  });
  const [recentActivity, setRecentActivity] = useState([]);
  const [alerts, setAlerts] = useState([]);

  // محاكاة جلب البيانات من الخادم
  useEffect(() => {
    // في التطبيق الحقيقي، سيتم استبدال هذا بطلبات API
    const fetchData = async () => {
      // محاكاة تأخير الشبكة
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // بيانات وهمية للعرض
      setStats({
        employees: 24,
        devices: 42,
        apkBuilds: 15,
        alerts: 3,
      });
      
      setRecentActivity([
        { id: 1, text: 'تم إضافة موظف جديد: أحمد محمد', time: 'منذ 10 دقائق' },
        { id: 2, text: 'تم إنشاء تطبيق جديد: تطبيق المبيعات v1.2', time: 'منذ 45 دقيقة' },
        { id: 3, text: 'تم تسجيل جهاز جديد: Samsung Galaxy S21', time: 'منذ ساعة واحدة' },
        { id: 4, text: 'تم تحديث بيانات الموظف: سارة أحمد', time: 'منذ 3 ساعات' },
        { id: 5, text: 'تم تعديل صلاحيات الجهاز: Device-2022-05', time: 'منذ 5 ساعات' },
      ]);
      
      setAlerts([
        { id: 1, text: 'جهاز غير متصل منذ 48 ساعة: Device-2022-03', severity: 'error' },
        { id: 2, text: 'فشل في بناء التطبيق: Sales App v1.3', severity: 'error' },
        { id: 3, text: 'تحذير: 5 أجهزة تحتاج إلى تحديث', severity: 'warning' },
      ]);
    };
    
    fetchData();
  }, []);

  return (
    <Container maxWidth="lg" className={classes.container}>
      <Typography variant="h4" component="h1" gutterBottom>
        لوحة التحكم
      </Typography>
      
      {/* بطاقات الإحصائيات */}
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={3}>
          <Paper className={`${classes.paper} ${classes.statsCard}`}>
            <Typography variant="h3" className={classes.statValue}>
              {stats.employees}
            </Typography>
            <Typography variant="subtitle1" className={classes.statLabel}>
              الموظفين
            </Typography>
            <PeopleIcon color="primary" fontSize="large" />
          </Paper>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Paper className={`${classes.paper} ${classes.statsCard}`}>
            <Typography variant="h3" className={classes.statValue}>
              {stats.devices}
            </Typography>
            <Typography variant="subtitle1" className={classes.statLabel}>
              الأجهزة
            </Typography>
            <DevicesIcon color="primary" fontSize="large" />
          </Paper>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Paper className={`${classes.paper} ${classes.statsCard}`}>
            <Typography variant="h3" className={classes.statValue}>
              {stats.apkBuilds}
            </Typography>
            <Typography variant="subtitle1" className={classes.statLabel}>
              التطبيقات المنشأة
            </Typography>
            <BuildIcon color="primary" fontSize="large" />
          </Paper>
        </Grid>
        
        <Grid item xs={12} sm={6} md={3}>
          <Paper className={`${classes.paper} ${classes.statsCard}`}>
            <Typography variant="h3" className={classes.statValue}>
              {stats.alerts}
            </Typography>
            <Typography variant="subtitle1" className={classes.statLabel}>
              التنبيهات
            </Typography>
            <NotificationsIcon color="error" fontSize="large" />
          </Paper>
        </Grid>
      </Grid>
      
      <Typography variant="h5" className={classes.sectionTitle}>
        التنبيهات والتحذيرات
      </Typography>
      
      {/* قسم التنبيهات */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper className={classes.paper}>
            <Typography variant="h6" gutterBottom>
              التنبيهات الحالية
            </Typography>
            <List>
              {alerts.map((alert) => (
                <ListItem 
                  key={alert.id} 
                  className={alert.severity === 'error' ? classes.alertItem : classes.warningItem}
                >
                  <ListItemIcon>
                    <WarningIcon color={alert.severity === 'error' ? 'error' : 'inherit'} />
                  </ListItemIcon>
                  <ListItemText primary={alert.text} />
                </ListItem>
              ))}
              {alerts.length === 0 && (
                <ListItem>
                  <ListItemText primary="لا توجد تنبيهات حالية" />
                </ListItem>
              )}
            </List>
            <Button 
              variant="outlined" 
              color="primary" 
              className={classes.actionButton}
              onClick={() => alert('سيتم تفعيل هذه الميزة لاحقًا')}
            >
              عرض جميع التنبيهات
            </Button>
          </Paper>
        </Grid>
        
        {/* قسم النشاطات الأخيرة */}
        <Grid item xs={12} md={6}>
          <Paper className={classes.paper}>
            <Typography variant="h6" gutterBottom>
              النشاطات الأخيرة
            </Typography>
            <List>
              {recentActivity.map((activity) => (
                <ListItem key={activity.id} className={classes.activityItem}>
                  <ListItemText 
                    primary={activity.text} 
                    secondary={activity.time} 
                  />
                </ListItem>
              ))}
            </List>
            <Button 
              variant="outlined" 
              color="primary" 
              className={classes.actionButton}
              onClick={() => alert('سيتم تفعيل هذه الميزة لاحقًا')}
            >
              عرض جميع النشاطات
            </Button>
          </Paper>
        </Grid>
      </Grid>
      
      {/* قسم الإجراءات السريعة */}
      <Typography variant="h5" className={classes.sectionTitle}>
        الإجراءات السريعة
      </Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={12}>
          <Paper className={classes.paper}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={4}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      إضافة موظف جديد
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      إضافة موظف جديد إلى النظام وتعيين الصلاحيات والأقسام
                    </Typography>
                    <Button 
                      variant="contained" 
                      color="primary" 
                      className={classes.actionButton}
                      onClick={() => alert('سيتم تفعيل هذه الميزة لاحقًا')}
                    >
                      إضافة موظف
                    </Button>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={4}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      تسجيل جهاز جديد
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      إضافة جهاز جديد إلى النظام وتعيينه لموظف
                    </Typography>
                    <Button 
                      variant="contained" 
                      color="primary" 
                      className={classes.actionButton}
                      onClick={() => alert('سيتم تفعيل هذه الميزة لاحقًا')}
                    >
                      تسجيل جهاز
                    </Button>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={4}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      إنشاء تطبيق جديد
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      إنشاء تطبيق أندرويد جديد بالإعدادات المخصصة
                    </Typography>
                    <Button 
                      variant="contained" 
                      color="primary" 
                      className={classes.actionButton}
                      onClick={() => alert('سيتم تفعيل هذه الميزة لاحقًا')}
                    >
                      إنشاء تطبيق
                    </Button>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Dashboard;