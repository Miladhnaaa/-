import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  makeStyles,
  Fab,
  Tooltip,
  CircularProgress,
  Switch,
  FormControlLabel,
  Chip,
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Send as SendIcon,
  Search as SearchIcon,
  PhoneAndroid as PhoneIcon,
  CheckCircle as OnlineIcon,
  Cancel as OfflineIcon,
  Lock as LockIcon,
  LockOpen as UnlockIcon,
  Visibility as VisibilityIcon,
} from '@material-ui/icons';

const useStyles = makeStyles((theme) => ({
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
  },
  paper: {
    padding: theme.spacing(3),
    display: 'flex',
    overflow: 'auto',
    flexDirection: 'column',
  },
  tableContainer: {
    marginTop: theme.spacing(3),
  },
  fab: {
    position: 'fixed',
    bottom: theme.spacing(4),
    left: theme.spacing(4),
  },
  formControl: {
    marginBottom: theme.spacing(2),
    minWidth: '100%',
  },
  searchContainer: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: theme.spacing(3),
  },
  searchInput: {
    marginLeft: theme.spacing(1),
    flex: 1,
  },
  searchButton: {
    padding: theme.spacing(1),
  },
  loadingContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing(5),
  },
  statusChip: {
    margin: theme.spacing(0.5),
  },
  permissionSection: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
    padding: theme.spacing(2),
    backgroundColor: theme.palette.background.default,
    borderRadius: theme.shape.borderRadius,
  },
  commandSection: {
    marginTop: theme.spacing(2),
  },
  commandInput: {
    marginBottom: theme.spacing(2),
  },
}));

const Devices = () => {
  const classes = useStyles();
  const [devices, setDevices] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [openCommandDialog, setOpenCommandDialog] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [formData, setFormData] = useState({
    deviceId: '',
    deviceName: '',
    deviceModel: '',
    assignedTo: '',
    status: 'active',
    permissions: {
      adminAccess: false,
      kioskMode: false,
      remoteControl: false,
    },
  });
  const [commandData, setCommandData] = useState({
    command: '',
    parameters: '',
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  // محاكاة جلب بيانات الأجهزة والموظفين من الخادم
  useEffect(() => {
    const fetchData = async () => {
      try {
        // محاكاة تأخير الشبكة
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // بيانات وهمية للموظفين
        const mockEmployees = [
          { id: '1', username: 'أحمد محمد' },
          { id: '2', username: 'سارة أحمد' },
          { id: '3', username: 'محمد علي' },
          { id: '4', username: 'فاطمة حسن' },
          { id: '5', username: 'خالد عبدالله' },
        ];
        
        // بيانات وهمية للأجهزة
        const mockDevices = [
          { 
            id: '1', 
            deviceId: 'DEV-2023-001', 
            deviceName: 'هاتف المبيعات 1', 
            deviceModel: 'Samsung Galaxy S21', 
            assignedTo: '3', 
            status: 'online',
            lastConnection: '2023-06-15T10:30:00',
            permissions: {
              adminAccess: false,
              kioskMode: true,
              remoteControl: true,
            },
          },
          { 
            id: '2', 
            deviceId: 'DEV-2023-002', 
            deviceName: 'هاتف المدير', 
            deviceModel: 'iPhone 13 Pro', 
            assignedTo: '1', 
            status: 'online',
            lastConnection: '2023-06-15T11:45:00',
            permissions: {
              adminAccess: true,
              kioskMode: false,
              remoteControl: true,
            },
          },
          { 
            id: '3', 
            deviceId: 'DEV-2023-003', 
            deviceName: 'جهاز الاستقبال', 
            deviceModel: 'Xiaomi Redmi Note 10', 
            assignedTo: '4', 
            status: 'offline',
            lastConnection: '2023-06-14T09:15:00',
            permissions: {
              adminAccess: false,
              kioskMode: true,
              remoteControl: false,
            },
          },
          { 
            id: '4', 
            deviceId: 'DEV-2023-004', 
            deviceName: 'هاتف الموارد البشرية', 
            deviceModel: 'Samsung Galaxy A52', 
            assignedTo: '2', 
            status: 'online',
            lastConnection: '2023-06-15T10:00:00',
            permissions: {
              adminAccess: false,
              kioskMode: false,
              remoteControl: true,
            },
          },
          { 
            id: '5', 
            deviceId: 'DEV-2023-005', 
            deviceName: 'جهاز غير مخصص', 
            deviceModel: 'Huawei P40 Lite', 
            assignedTo: '', 
            status: 'inactive',
            lastConnection: '2023-06-10T14:20:00',
            permissions: {
              adminAccess: false,
              kioskMode: false,
              remoteControl: false,
            },
          },
        ];
        
        setEmployees(mockEmployees);
        setDevices(mockDevices);
      } catch (error) {
        console.error('Error fetching data:', error);
        setSnackbar({
          open: true,
          message: 'حدث خطأ أثناء جلب البيانات',
          severity: 'error',
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);

  const handleOpenDialog = (device = null) => {
    if (device) {
      setSelectedDevice(device);
      setFormData({
        deviceId: device.deviceId,
        deviceName: device.deviceName,
        deviceModel: device.deviceModel,
        assignedTo: device.assignedTo,
        status: device.status,
        permissions: {
          adminAccess: device.permissions.adminAccess,
          kioskMode: device.permissions.kioskMode,
          remoteControl: device.permissions.remoteControl,
        },
      });
    } else {
      setSelectedDevice(null);
      setFormData({
        deviceId: `DEV-${new Date().getFullYear()}-${String(devices.length + 1).padStart(3, '0')}`,
        deviceName: '',
        deviceModel: '',
        assignedTo: '',
        status: 'inactive',
        permissions: {
          adminAccess: false,
          kioskMode: false,
          remoteControl: false,
        },
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleOpenDeleteDialog = (device) => {
    setSelectedDevice(device);
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => {
    setOpenDeleteDialog(false);
  };

  const handleOpenCommandDialog = (device) => {
    setSelectedDevice(device);
    setCommandData({
      command: '',
      parameters: '',
    });
    setOpenCommandDialog(true);
  };

  const handleCloseCommandDialog = () => {
    setOpenCommandDialog(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handlePermissionChange = (e) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      permissions: {
        ...formData.permissions,
        [name]: checked,
      },
    });
  };

  const handleCommandChange = (e) => {
    const { name, value } = e.target;
    setCommandData({
      ...commandData,
      [name]: value,
    });
  };

  const handleSubmit = async () => {
    try {
      setLoading(true);
      
      // محاكاة تأخير الشبكة
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (selectedDevice) {
        // تحديث جهاز موجود
        const updatedDevices = devices.map(dev =>
          dev.id === selectedDevice.id
            ? { 
                ...dev, 
                deviceId: formData.deviceId,
                deviceName: formData.deviceName,
                deviceModel: formData.deviceModel,
                assignedTo: formData.assignedTo,
                status: formData.status,
                permissions: formData.permissions,
              }
            : dev
        );
        setDevices(updatedDevices);
        setSnackbar({
          open: true,
          message: 'تم تحديث بيانات الجهاز بنجاح',
          severity: 'success',
        });
      } else {
        // إضافة جهاز جديد
        const newDevice = {
          id: Date.now().toString(),
          deviceId: formData.deviceId,
          deviceName: formData.deviceName,
          deviceModel: formData.deviceModel,
          assignedTo: formData.assignedTo,
          status: formData.status,
          lastConnection: new Date().toISOString(),
          permissions: formData.permissions,
        };
        setDevices([...devices, newDevice]);
        setSnackbar({
          open: true,
          message: 'تم إضافة الجهاز بنجاح',
          severity: 'success',
        });
      }
      
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving device:', error);
      setSnackbar({
        open: true,
        message: 'حدث خطأ أثناء حفظ بيانات الجهاز',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    try {
      setLoading(true);
      
      // محاكاة تأخير الشبكة
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const updatedDevices = devices.filter(dev => dev.id !== selectedDevice.id);
      setDevices(updatedDevices);
      
      setSnackbar({
        open: true,
        message: 'تم حذف الجهاز بنجاح',
        severity: 'success',
      });
      
      handleCloseDeleteDialog();
    } catch (error) {
      console.error('Error deleting device:', error);
      setSnackbar({
        open: true,
        message: 'حدث خطأ أثناء حذف الجهاز',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSendCommand = async () => {
    try {
      setLoading(true);
      
      // محاكاة تأخير الشبكة
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log('Sending command to device:', selectedDevice.deviceId);
      console.log('Command:', commandData.command);
      console.log('Parameters:', commandData.parameters);
      
      setSnackbar({
        open: true,
        message: 'تم إرسال الأمر إلى الجهاز بنجاح',
        severity: 'success',
      });
      
      handleCloseCommandDialog();
    } catch (error) {
      console.error('Error sending command:', error);
      setSnackbar({
        open: true,
        message: 'حدث خطأ أثناء إرسال الأمر إلى الجهاز',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    // في التطبيق الحقيقي، سيتم إرسال طلب بحث إلى الخادم
    console.log('Searching for:', searchTerm);
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false,
    });
  };

  const getEmployeeName = (id) => {
    if (!id) return 'غير مخصص';
    const employee = employees.find(emp => emp.id === id);
    return employee ? employee.username : 'غير معروف';
  };

  const filteredDevices = devices.filter(device =>
    device.deviceId.includes(searchTerm) ||
    device.deviceName.includes(searchTerm) ||
    device.deviceModel.includes(searchTerm) ||
    getEmployeeName(device.assignedTo).includes(searchTerm)
  );

  return (
    <Container maxWidth="lg" className={classes.container}>
      <Typography variant="h4" component="h1" gutterBottom>
        إدارة الأجهزة
      </Typography>
      
      {/* حقل البحث */}
      <Paper className={classes.paper}>
        <div className={classes.searchContainer}>
          <TextField
            className={classes.searchInput}
            label="بحث عن جهاز"
            variant="outlined"
            size="small"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Button
            variant="contained"
            color="primary"
            className={classes.searchButton}
            startIcon={<SearchIcon />}
            onClick={handleSearch}
          >
            بحث
          </Button>
        </div>
      </Paper>
      
      {/* جدول الأجهزة */}
      <Paper className={classes.paper}>
        <TableContainer className={classes.tableContainer}>
          {loading && devices.length === 0 ? (
            <div className={classes.loadingContainer}>
              <CircularProgress />
              <Typography variant="body1" style={{ marginRight: '10px' }}>
                جاري تحميل بيانات الأجهزة...
              </Typography>
            </div>
          ) : (
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>معرف الجهاز</TableCell>
                  <TableCell>اسم الجهاز</TableCell>
                  <TableCell>الموديل</TableCell>
                  <TableCell>المستخدم</TableCell>
                  <TableCell>الحالة</TableCell>
                  <TableCell>الصلاحيات</TableCell>
                  <TableCell>الإجراءات</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredDevices.length > 0 ? (
                  filteredDevices.map((device) => (
                    <TableRow key={device.id}>
                      <TableCell>{device.deviceId}</TableCell>
                      <TableCell>{device.deviceName}</TableCell>
                      <TableCell>{device.deviceModel}</TableCell>
                      <TableCell>{getEmployeeName(device.assignedTo)}</TableCell>
                      <TableCell>
                        {device.status === 'online' && (
                          <Chip
                            icon={<OnlineIcon />}
                            label="متصل"
                            className={classes.statusChip}
                            color="primary"
                            size="small"
                          />
                        )}
                        {device.status === 'offline' && (
                          <Chip
                            icon={<OfflineIcon />}
                            label="غير متصل"
                            className={classes.statusChip}
                            color="default"
                            size="small"
                          />
                        )}
                        {device.status === 'inactive' && (
                          <Chip
                            icon={<OfflineIcon />}
                            label="غير نشط"
                            className={classes.statusChip}
                            color="secondary"
                            size="small"
                          />
                        )}
                      </TableCell>
                      <TableCell>
                        {device.permissions.adminAccess && (
                          <Tooltip title="وصول المسؤول">
                            <Chip
                              icon={<LockOpenIcon />}
                              label="مسؤول"
                              className={classes.statusChip}
                              color="secondary"
                              size="small"
                            />
                          </Tooltip>
                        )}
                        {device.permissions.kioskMode && (
                          <Tooltip title="وضع الكشك">
                            <Chip
                              icon={<LockIcon />}
                              label="كشك"
                              className={classes.statusChip}
                              color="primary"
                              size="small"
                            />
                          </Tooltip>
                        )}
                        {device.permissions.remoteControl && (
                          <Tooltip title="التحكم عن بعد">
                            <Chip
                              icon={<VisibilityIcon />}
                              label="تحكم"
                              className={classes.statusChip}
                              color="primary"
                              size="small"
                            />
                          </Tooltip>
                        )}
                      </TableCell>
                      <TableCell>
                        <Tooltip title="تعديل">
                          <IconButton color="primary" onClick={() => handleOpenDialog(device)}>
                            <EditIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="إرسال أمر">
                          <IconButton 
                            color="primary" 
                            onClick={() => handleOpenCommandDialog(device)}
                            disabled={device.status !== 'online'}
                          >
                            <SendIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="حذف">
                          <IconButton color="secondary" onClick={() => handleOpenDeleteDialog(device)}>
                            <DeleteIcon />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      لا توجد بيانات للعرض
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </TableContainer>
      </Paper>
      
      {/* زر إضافة جهاز جديد */}
      <Tooltip title="إضافة جهاز جديد">
        <Fab color="primary" className={classes.fab} onClick={() => handleOpenDialog()}>
          <AddIcon />
        </Fab>
      </Tooltip>
      
      {/* نموذج إضافة/تعديل جهاز */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {selectedDevice ? 'تعديل بيانات الجهاز' : 'إضافة جهاز جديد'}
        </DialogTitle>
        <DialogContent>
          <FormControl className={classes.formControl}>
            <TextField
              margin="dense"
              name="deviceId"
              label="معرف الجهاز"
              type="text"
              fullWidth
              value={formData.deviceId}
              onChange={handleChange}
              required
              disabled={selectedDevice !== null}
            />
          </FormControl>
          
          <FormControl className={classes.formControl}>
            <TextField
              autoFocus
              margin="dense"
              name="deviceName"
              label="اسم الجهاز"
              type="text"
              fullWidth
              value={formData.deviceName}
              onChange={handleChange}
              required
            />
          </FormControl>
          
          <FormControl className={classes.formControl}>
            <TextField
              margin="dense"
              name="deviceModel"
              label="موديل الجهاز"
              type="text"
              fullWidth
              value={formData.deviceModel}
              onChange={handleChange}
              required
            />
          </FormControl>
          
          <FormControl className={classes.formControl}>
            <InputLabel>المستخدم المخصص</InputLabel>
            <Select
              name="assignedTo"
              value={formData.assignedTo}
              onChange={handleChange}
              fullWidth
            >
              <MenuItem value="">غير مخصص</MenuItem>
              {employees.map((employee) => (
                <MenuItem key={employee.id} value={employee.id}>
                  {employee.username}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          
          <FormControl className={classes.formControl}>
            <InputLabel>الحالة</InputLabel>
            <Select
              name="status"
              value={formData.status}
              onChange={handleChange}
              fullWidth
            >
              <MenuItem value="online">متصل</MenuItem>
              <MenuItem value="offline">غير متصل</MenuItem>
              <MenuItem value="inactive">غير نشط</MenuItem>
            </Select>
          </FormControl>
          
          <div className={classes.permissionSection}>
            <Typography variant="subtitle1" gutterBottom>
              الصلاحيات
            </Typography>
            
            <FormControlLabel
              control={
                <Switch
                  checked={formData.permissions.adminAccess}
                  onChange={handlePermissionChange}
                  name="adminAccess"
                  color="primary"
                />
              }
              label="وصول المسؤول"
            />
            
            <FormControlLabel
              control={
                <Switch
                  checked={formData.permissions.kioskMode}
                  onChange={handlePermissionChange}
                  name="kioskMode"
                  color="primary"
                />
              }
              label="وضع الكشك"
            />
            
            <FormControlLabel
              control={
                <Switch
                  checked={formData.permissions.remoteControl}
                  onChange={handlePermissionChange}
                  name="remoteControl"
                  color="primary"
                />
              }
              label="التحكم عن بعد"
            />
          </div>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} color="default">
            إلغاء
          </Button>
          <Button onClick={handleSubmit} color="primary" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : 'حفظ'}
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* مربع حوار تأكيد الحذف */}
      <Dialog open={openDeleteDialog} onClose={handleCloseDeleteDialog}>
        <DialogTitle>تأكيد الحذف</DialogTitle>
        <DialogContent>
          <Typography>
            هل أنت متأكد من رغبتك في حذف الجهاز: {selectedDevice?.deviceName} ({selectedDevice?.deviceId})؟
          </Typography>
          {selectedDevice?.assignedTo && (
            <Typography color="error" style={{ marginTop: '10px' }}>
              تحذير: هذا الجهاز مخصص لـ {getEmployeeName(selectedDevice.assignedTo)}. سيتم إلغاء تخصيص الجهاز.
            </Typography>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDeleteDialog} color="default">
            إلغاء
          </Button>
          <Button onClick={handleDelete} color="secondary" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : 'حذف'}
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* مربع حوار إرسال أمر */}
      <Dialog open={openCommandDialog} onClose={handleCloseCommandDialog}>
        <DialogTitle>إرسال أمر إلى الجهاز</DialogTitle>
        <DialogContent>
          <Typography gutterBottom>
            إرسال أمر إلى الجهاز: {selectedDevice?.deviceName} ({selectedDevice?.deviceId})
          </Typography>
          
          <FormControl className={`${classes.formControl} ${classes.commandInput}`}>
            <InputLabel>الأمر</InputLabel>
            <Select
              name="command"
              value={commandData.command}
              onChange={handleCommandChange}
              fullWidth
            >
              <MenuItem value="">اختر أمرًا</MenuItem>
              <MenuItem value="refresh">تحديث التطبيق</MenuItem>
              <MenuItem value="restart">إعادة تشغيل التطبيق</MenuItem>
              <MenuItem value="lock">قفل الجهاز</MenuItem>
              <MenuItem value="unlock">فتح الجهاز</MenuItem>
              <MenuItem value="screenshot">التقاط صورة للشاشة</MenuItem>
              <MenuItem value="location">الحصول على الموقع</MenuItem>
              <MenuItem value="custom">أمر مخصص</MenuItem>
            </Select>
          </FormControl>
          
          {commandData.command === 'custom' && (
            <FormControl className={classes.formControl}>
              <TextField
                margin="dense"
                name="parameters"
                label="معلمات الأمر (JSON)"
                type="text"
                fullWidth
                multiline
                rows={4}
                value={commandData.parameters}
                onChange={handleCommandChange}
                placeholder='{"action": "value", "param": "value"}'
              />
            </FormControl>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseCommandDialog} color="default">
            إلغاء
          </Button>
          <Button 
            onClick={handleSendCommand} 
            color="primary" 
            disabled={loading || !commandData.command}
          >
            {loading ? <CircularProgress size={24} /> : 'إرسال'}
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* رسائل التنبيه */}
      <Snackbar open={snackbar.open} autoHideDuration={6000} onClose={handleCloseSnackbar}>
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default Devices;