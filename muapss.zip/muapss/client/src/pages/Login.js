import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Grid,
  Snackbar,
  makeStyles
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    padding: theme.spacing(4),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
    padding: theme.spacing(2),
    borderRadius: '50%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  form: {
    width: '100%',
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
    padding: theme.spacing(1.5),
  },
  title: {
    marginBottom: theme.spacing(3),
  },
}));

const Login = () => {
  const classes = useStyles();
  const history = useHistory();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [openSnackbar, setOpenSnackbar] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // سيتم استبدال هذا بطلب API حقيقي لاحقًا
      // const response = await axios.post('/api/auth/login', formData);
      
      // محاكاة طلب API
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // محاكاة استجابة ناجحة
      const mockResponse = {
        data: {
          token: 'mock-jwt-token',
          user: {
            id: '1',
            name: 'مدير النظام',
            email: formData.email,
            role: 'admin'
          }
        }
      };

      // تخزين بيانات المستخدم في التخزين المحلي
      localStorage.setItem('token', mockResponse.data.token);
      localStorage.setItem('user', JSON.stringify(mockResponse.data.user));
      
      setOpenSnackbar(true);
      
      // توجيه المستخدم إلى لوحة التحكم بعد تسجيل الدخول
      setTimeout(() => {
        history.push('/dashboard');
      }, 1500);
    } catch (err) {
      setError(err.response?.data?.message || 'حدث خطأ أثناء تسجيل الدخول');
    } finally {
      setLoading(false);
    }
  };

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  return (
    <Container component="main" maxWidth="xs">
      <Paper className={classes.paper} elevation={3}>
        <div className={classes.avatar}>
          <LockOutlinedIcon fontSize="large" />
        </div>
        <Typography component="h1" variant="h5" className={classes.title}>
          تسجيل الدخول
        </Typography>
        
        {error && (
          <Alert severity="error" style={{ width: '100%', marginBottom: '16px' }}>
            {error}
          </Alert>
        )}
        
        <form className={classes.form} onSubmit={handleSubmit}>
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="email"
            label="البريد الإلكتروني"
            name="email"
            autoComplete="email"
            autoFocus
            value={formData.email}
            onChange={handleChange}
            dir="rtl"
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            name="password"
            label="كلمة المرور"
            type="password"
            id="password"
            autoComplete="current-password"
            value={formData.password}
            onChange={handleChange}
            dir="rtl"
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
            disabled={loading}
          >
            {loading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
          </Button>
          <Grid container justifyContent="center">
            <Grid item>
              <Button color="primary" onClick={() => alert('سيتم تفعيل هذه الميزة لاحقًا')}>
                نسيت كلمة المرور؟
              </Button>
            </Grid>
          </Grid>
        </form>
      </Paper>
      
      <Snackbar open={openSnackbar} autoHideDuration={3000} onClose={handleCloseSnackbar}>
        <Alert onClose={handleCloseSnackbar} severity="success">
          تم تسجيل الدخول بنجاح!
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default Login;