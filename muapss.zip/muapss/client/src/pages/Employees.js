import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  makeStyles,
  Fab,
  Tooltip,
  CircularProgress,
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  PhoneAndroid as DeviceIcon,
  Search as SearchIcon,
} from '@material-ui/icons';

const useStyles = makeStyles((theme) => ({
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
  },
  paper: {
    padding: theme.spacing(3),
    display: 'flex',
    overflow: 'auto',
    flexDirection: 'column',
  },
  tableContainer: {
    marginTop: theme.spacing(3),
  },
  fab: {
    position: 'fixed',
    bottom: theme.spacing(4),
    left: theme.spacing(4),
  },
  formControl: {
    marginBottom: theme.spacing(2),
    minWidth: '100%',
  },
  searchContainer: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: theme.spacing(3),
  },
  searchInput: {
    marginLeft: theme.spacing(1),
    flex: 1,
  },
  searchButton: {
    padding: theme.spacing(1),
  },
  loadingContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing(5),
  },
}));

const Employees = () => {
  const classes = useStyles();
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    role: 'user',
    department: '',
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  // محاكاة جلب بيانات الموظفين من الخادم
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        // محاكاة تأخير الشبكة
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // بيانات وهمية للعرض
        const mockEmployees = [
          { id: '1', username: 'أحمد محمد', email: 'ahmed@example.com', role: 'admin', department: 'تكنولوجيا المعلومات', deviceCount: 2 },
          { id: '2', username: 'سارة أحمد', email: 'sara@example.com', role: 'manager', department: 'الموارد البشرية', deviceCount: 1 },
          { id: '3', username: 'محمد علي', email: 'mohamed@example.com', role: 'user', department: 'المبيعات', deviceCount: 3 },
          { id: '4', username: 'فاطمة حسن', email: 'fatima@example.com', role: 'user', department: 'خدمة العملاء', deviceCount: 0 },
          { id: '5', username: 'خالد عبدالله', email: 'khaled@example.com', role: 'user', department: 'المالية', deviceCount: 1 },
        ];
        
        setEmployees(mockEmployees);
      } catch (error) {
        console.error('Error fetching employees:', error);
        setSnackbar({
          open: true,
          message: 'حدث خطأ أثناء جلب بيانات الموظفين',
          severity: 'error',
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchEmployees();
  }, []);

  const handleOpenDialog = (employee = null) => {
    if (employee) {
      setSelectedEmployee(employee);
      setFormData({
        username: employee.username,
        email: employee.email,
        password: '',
        role: employee.role,
        department: employee.department,
      });
    } else {
      setSelectedEmployee(null);
      setFormData({
        username: '',
        email: '',
        password: '',
        role: 'user',
        department: '',
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleOpenDeleteDialog = (employee) => {
    setSelectedEmployee(employee);
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => {
    setOpenDeleteDialog(false);
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async () => {
    try {
      setLoading(true);
      
      // محاكاة تأخير الشبكة
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (selectedEmployee) {
        // تحديث موظف موجود
        const updatedEmployees = employees.map(emp =>
          emp.id === selectedEmployee.id
            ? { ...emp, ...formData, deviceCount: emp.deviceCount }
            : emp
        );
        setEmployees(updatedEmployees);
        setSnackbar({
          open: true,
          message: 'تم تحديث بيانات الموظف بنجاح',
          severity: 'success',
        });
      } else {
        // إضافة موظف جديد
        const newEmployee = {
          id: Date.now().toString(),
          ...formData,
          deviceCount: 0,
        };
        setEmployees([...employees, newEmployee]);
        setSnackbar({
          open: true,
          message: 'تم إضافة الموظف بنجاح',
          severity: 'success',
        });
      }
      
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving employee:', error);
      setSnackbar({
        open: true,
        message: 'حدث خطأ أثناء حفظ بيانات الموظف',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    try {
      setLoading(true);
      
      // محاكاة تأخير الشبكة
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const updatedEmployees = employees.filter(emp => emp.id !== selectedEmployee.id);
      setEmployees(updatedEmployees);
      
      setSnackbar({
        open: true,
        message: 'تم حذف الموظف بنجاح',
        severity: 'success',
      });
      
      handleCloseDeleteDialog();
    } catch (error) {
      console.error('Error deleting employee:', error);
      setSnackbar({
        open: true,
        message: 'حدث خطأ أثناء حذف الموظف',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    // في التطبيق الحقيقي، سيتم إرسال طلب بحث إلى الخادم
    console.log('Searching for:', searchTerm);
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false,
    });
  };

  const filteredEmployees = employees.filter(employee =>
    employee.username.includes(searchTerm) ||
    employee.email.includes(searchTerm) ||
    employee.department.includes(searchTerm)
  );

  return (
    <Container maxWidth="lg" className={classes.container}>
      <Typography variant="h4" component="h1" gutterBottom>
        إدارة الموظفين
      </Typography>
      
      {/* حقل البحث */}
      <Paper className={classes.paper}>
        <div className={classes.searchContainer}>
          <TextField
            className={classes.searchInput}
            label="بحث عن موظف"
            variant="outlined"
            size="small"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Button
            variant="contained"
            color="primary"
            className={classes.searchButton}
            startIcon={<SearchIcon />}
            onClick={handleSearch}
          >
            بحث
          </Button>
        </div>
      </Paper>
      
      {/* جدول الموظفين */}
      <Paper className={classes.paper}>
        <TableContainer className={classes.tableContainer}>
          {loading && employees.length === 0 ? (
            <div className={classes.loadingContainer}>
              <CircularProgress />
              <Typography variant="body1" style={{ marginRight: '10px' }}>
                جاري تحميل بيانات الموظفين...
              </Typography>
            </div>
          ) : (
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>اسم المستخدم</TableCell>
                  <TableCell>البريد الإلكتروني</TableCell>
                  <TableCell>الدور</TableCell>
                  <TableCell>القسم</TableCell>
                  <TableCell>الأجهزة</TableCell>
                  <TableCell>الإجراءات</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredEmployees.length > 0 ? (
                  filteredEmployees.map((employee) => (
                    <TableRow key={employee.id}>
                      <TableCell>{employee.username}</TableCell>
                      <TableCell>{employee.email}</TableCell>
                      <TableCell>
                        {employee.role === 'admin' && 'مدير النظام'}
                        {employee.role === 'manager' && 'مدير'}
                        {employee.role === 'user' && 'مستخدم'}
                      </TableCell>
                      <TableCell>{employee.department}</TableCell>
                      <TableCell>
                        <Tooltip title={`${employee.deviceCount} جهاز`}>
                          <div style={{ display: 'flex', alignItems: 'center' }}>
                            <DeviceIcon color={employee.deviceCount > 0 ? 'primary' : 'disabled'} />
                            <span style={{ marginRight: '5px' }}>{employee.deviceCount}</span>
                          </div>
                        </Tooltip>
                      </TableCell>
                      <TableCell>
                        <Tooltip title="تعديل">
                          <IconButton color="primary" onClick={() => handleOpenDialog(employee)}>
                            <EditIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="حذف">
                          <IconButton color="secondary" onClick={() => handleOpenDeleteDialog(employee)}>
                            <DeleteIcon />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} align="center">
                      لا توجد بيانات للعرض
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </TableContainer>
      </Paper>
      
      {/* زر إضافة موظف جديد */}
      <Tooltip title="إضافة موظف جديد">
        <Fab color="primary" className={classes.fab} onClick={() => handleOpenDialog()}>
          <AddIcon />
        </Fab>
      </Tooltip>
      
      {/* نموذج إضافة/تعديل موظف */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {selectedEmployee ? 'تعديل بيانات الموظف' : 'إضافة موظف جديد'}
        </DialogTitle>
        <DialogContent>
          <FormControl className={classes.formControl}>
            <TextField
              autoFocus
              margin="dense"
              name="username"
              label="اسم المستخدم"
              type="text"
              fullWidth
              value={formData.username}
              onChange={handleChange}
              required
            />
          </FormControl>
          
          <FormControl className={classes.formControl}>
            <TextField
              margin="dense"
              name="email"
              label="البريد الإلكتروني"
              type="email"
              fullWidth
              value={formData.email}
              onChange={handleChange}
              required
            />
          </FormControl>
          
          <FormControl className={classes.formControl}>
            <TextField
              margin="dense"
              name="password"
              label={selectedEmployee ? 'كلمة المرور (اتركها فارغة إذا لم ترغب في تغييرها)' : 'كلمة المرور'}
              type="password"
              fullWidth
              value={formData.password}
              onChange={handleChange}
              required={!selectedEmployee}
            />
          </FormControl>
          
          <FormControl className={classes.formControl}>
            <InputLabel>الدور</InputLabel>
            <Select
              name="role"
              value={formData.role}
              onChange={handleChange}
              fullWidth
            >
              <MenuItem value="admin">مدير النظام</MenuItem>
              <MenuItem value="manager">مدير</MenuItem>
              <MenuItem value="user">مستخدم</MenuItem>
            </Select>
          </FormControl>
          
          <FormControl className={classes.formControl}>
            <TextField
              margin="dense"
              name="department"
              label="القسم"
              type="text"
              fullWidth
              value={formData.department}
              onChange={handleChange}
            />
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} color="default">
            إلغاء
          </Button>
          <Button onClick={handleSubmit} color="primary" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : 'حفظ'}
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* مربع حوار تأكيد الحذف */}
      <Dialog open={openDeleteDialog} onClose={handleCloseDeleteDialog}>
        <DialogTitle>تأكيد الحذف</DialogTitle>
        <DialogContent>
          <Typography>
            هل أنت متأكد من رغبتك في حذف الموظف: {selectedEmployee?.username}؟
          </Typography>
          {selectedEmployee?.deviceCount > 0 && (
            <Typography color="error" style={{ marginTop: '10px' }}>
              تحذير: هذا الموظف لديه {selectedEmployee.deviceCount} جهاز مرتبط به. سيتم إلغاء ارتباط هذه الأجهزة.
            </Typography>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDeleteDialog} color="default">
            إلغاء
          </Button>
          <Button onClick={handleDelete} color="secondary" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : 'حذف'}
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* رسائل التنبيه */}
      <Snackbar open={snackbar.open} autoHideDuration={6000} onClose={handleCloseSnackbar}>
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default Employees;