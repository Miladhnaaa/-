import React, { useState } from 'react';
import {
  Container,
  Paper,
  Typography,
  Divider,
  Grid,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  Snackbar,
  makeStyles,
} from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import {
  Save as SaveIcon,
  Refresh as RefreshIcon,
} from '@material-ui/icons';

const useStyles = makeStyles((theme) => ({
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
  },
  paper: {
    padding: theme.spacing(3),
    marginBottom: theme.spacing(3),
  },
  divider: {
    margin: theme.spacing(3, 0),
  },
  formControl: {
    marginBottom: theme.spacing(2),
    minWidth: '100%',
  },
  buttonContainer: {
    display: 'flex',
    justifyContent: 'flex-end',
    marginTop: theme.spacing(2),
  },
  button: {
    marginRight: theme.spacing(1),
  },
}));

const Settings = () => {
  const classes = useStyles();
  
  // حالة الإعدادات
  const [generalSettings, setGeneralSettings] = useState({
    companyName: 'شركة التقنية المتقدمة',
    email: 'info@advancedtech.com',
    phone: '+966 12 345 6789',
    address: 'الرياض، المملكة العربية السعودية',
    language: 'ar',
    timezone: 'Asia/Riyadh',
    dateFormat: 'DD/MM/YYYY',
    timeFormat: '24',
  });
  
  const [serverSettings, setServerSettings] = useState({
    serverUrl: 'http://localhost',
    serverPort: '5000',
    socketEnabled: true,
    apiPrefix: '/api',
    maxUploadSize: '10',
    sessionTimeout: '60',
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    smsNotifications: false,
    notifyOnNewDevice: true,
    notifyOnDeviceOffline: true,
    notifyOnApkBuild: true,
    dailyReportEnabled: true,
    dailyReportTime: '08:00',
  });
  
  // حالة رسائل التنبيه
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success',
  });
  
  // معالجة تغيير الإعدادات العامة
  const handleGeneralChange = (e) => {
    const { name, value } = e.target;
    setGeneralSettings({
      ...generalSettings,
      [name]: value,
    });
  };
  
  // معالجة تغيير إعدادات الخادم
  const handleServerChange = (e) => {
    const { name, value, type, checked } = e.target;
    setServerSettings({
      ...serverSettings,
      [name]: type === 'checkbox' ? checked : value,
    });
  };
  
  // معالجة تغيير إعدادات الإشعارات
  const handleNotificationChange = (e) => {
    const { name, value, type, checked } = e.target;
    setNotificationSettings({
      ...notificationSettings,
      [name]: type === 'checkbox' ? checked : value,
    });
  };
  
  // حفظ الإعدادات
  const handleSaveSettings = () => {
    // محاكاة حفظ الإعدادات على الخادم
    setTimeout(() => {
      setSnackbar({
        open: true,
        message: 'تم حفظ الإعدادات بنجاح',
        severity: 'success',
      });
    }, 1000);
  };
  
  // إعادة تعيين الإعدادات
  const handleResetSettings = () => {
    // محاكاة إعادة تعيين الإعدادات من الخادم
    setTimeout(() => {
      setGeneralSettings({
        companyName: 'شركة التقنية المتقدمة',
        email: 'info@advancedtech.com',
        phone: '+966 12 345 6789',
        address: 'الرياض، المملكة العربية السعودية',
        language: 'ar',
        timezone: 'Asia/Riyadh',
        dateFormat: 'DD/MM/YYYY',
        timeFormat: '24',
      });
      
      setServerSettings({
        serverUrl: 'http://localhost',
        serverPort: '5000',
        socketEnabled: true,
        apiPrefix: '/api',
        maxUploadSize: '10',
        sessionTimeout: '60',
      });
      
      setNotificationSettings({
        emailNotifications: true,
        pushNotifications: true,
        smsNotifications: false,
        notifyOnNewDevice: true,
        notifyOnDeviceOffline: true,
        notifyOnApkBuild: true,
        dailyReportEnabled: true,
        dailyReportTime: '08:00',
      });
      
      setSnackbar({
        open: true,
        message: 'تم إعادة تعيين الإعدادات',
        severity: 'info',
      });
    }, 1000);
  };
  
  // إغلاق رسالة التنبيه
  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false,
    });
  };
  
  return (
    <Container maxWidth="lg" className={classes.container}>
      <Typography variant="h4" component="h1" gutterBottom>
        إعدادات النظام
      </Typography>
      
      {/* الإعدادات العامة */}
      <Paper className={classes.paper}>
        <Typography variant="h6" gutterBottom>
          الإعدادات العامة
        </Typography>
        
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <TextField
                label="اسم الشركة"
                name="companyName"
                value={generalSettings.companyName}
                onChange={handleGeneralChange}
                fullWidth
              />
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <TextField
                label="البريد الإلكتروني"
                name="email"
                type="email"
                value={generalSettings.email}
                onChange={handleGeneralChange}
                fullWidth
              />
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <TextField
                label="رقم الهاتف"
                name="phone"
                value={generalSettings.phone}
                onChange={handleGeneralChange}
                fullWidth
              />
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <TextField
                label="العنوان"
                name="address"
                value={generalSettings.address}
                onChange={handleGeneralChange}
                fullWidth
              />
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <InputLabel>اللغة</InputLabel>
              <Select
                name="language"
                value={generalSettings.language}
                onChange={handleGeneralChange}
                fullWidth
              >
                <MenuItem value="ar">العربية</MenuItem>
                <MenuItem value="en">الإنجليزية</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <InputLabel>المنطقة الزمنية</InputLabel>
              <Select
                name="timezone"
                value={generalSettings.timezone}
                onChange={handleGeneralChange}
                fullWidth
              >
                <MenuItem value="Asia/Riyadh">الرياض (GMT+3)</MenuItem>
                <MenuItem value="Asia/Dubai">دبي (GMT+4)</MenuItem>
                <MenuItem value="Asia/Kuwait">الكويت (GMT+3)</MenuItem>
                <MenuItem value="Africa/Cairo">القاهرة (GMT+2)</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <InputLabel>تنسيق التاريخ</InputLabel>
              <Select
                name="dateFormat"
                value={generalSettings.dateFormat}
                onChange={handleGeneralChange}
                fullWidth
              >
                <MenuItem value="DD/MM/YYYY">DD/MM/YYYY</MenuItem>
                <MenuItem value="MM/DD/YYYY">MM/DD/YYYY</MenuItem>
                <MenuItem value="YYYY-MM-DD">YYYY-MM-DD</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <InputLabel>تنسيق الوقت</InputLabel>
              <Select
                name="timeFormat"
                value={generalSettings.timeFormat}
                onChange={handleGeneralChange}
                fullWidth
              >
                <MenuItem value="12">12 ساعة (AM/PM)</MenuItem>
                <MenuItem value="24">24 ساعة</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </Paper>
      
      {/* إعدادات الخادم */}
      <Paper className={classes.paper}>
        <Typography variant="h6" gutterBottom>
          إعدادات الخادم
        </Typography>
        
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <TextField
                label="عنوان الخادم"
                name="serverUrl"
                value={serverSettings.serverUrl}
                onChange={handleServerChange}
                fullWidth
              />
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <TextField
                label="منفذ الخادم"
                name="serverPort"
                value={serverSettings.serverPort}
                onChange={handleServerChange}
                fullWidth
              />
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <TextField
                label="بادئة API"
                name="apiPrefix"
                value={serverSettings.apiPrefix}
                onChange={handleServerChange}
                fullWidth
              />
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <TextField
                label="الحد الأقصى لحجم الملف (ميجابايت)"
                name="maxUploadSize"
                type="number"
                value={serverSettings.maxUploadSize}
                onChange={handleServerChange}
                fullWidth
              />
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl}>
              <TextField
                label="مهلة الجلسة (دقائق)"
                name="sessionTimeout"
                type="number"
                value={serverSettings.sessionTimeout}
                onChange={handleServerChange}
                fullWidth
              />
            </FormControl>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControlLabel
              control={
                <Switch
                  checked={serverSettings.socketEnabled}
                  onChange={handleServerChange}
                  name="socketEnabled"
                  color="primary"
                />
              }
              label="تمكين اتصالات Socket.IO"
            />
          </Grid>
        </Grid>
      </Paper>
      
      {/* إعدادات الإشعارات */}
      <Paper className={classes.paper}>
        <Typography variant="h6" gutterBottom>
          إعدادات الإشعارات
        </Typography>
        
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <FormControlLabel
              control={
                <Switch
                  checked={notificationSettings.emailNotifications}
                  onChange={handleNotificationChange}
                  name="emailNotifications"
                  color="primary"
                />
              }
              label="إشعارات البريد الإلكتروني"
            />
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControlLabel
              control={
                <Switch
                  checked={notificationSettings.pushNotifications}
                  onChange={handleNotificationChange}
                  name="pushNotifications"
                  color="primary"
                />
              }
              label="إشعارات الدفع"
            />
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControlLabel
              control={
                <Switch
                  checked={notificationSettings.smsNotifications}
                  onChange={handleNotificationChange}
                  name="smsNotifications"
                  color="primary"
                />
              }
              label="إشعارات الرسائل القصيرة"
            />
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControlLabel
              control={
                <Switch
                  checked={notificationSettings.notifyOnNewDevice}
                  onChange={handleNotificationChange}
                  name="notifyOnNewDevice"
                  color="primary"
                />
              }
              label="إشعار عند إضافة جهاز جديد"
            />
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControlLabel
              control={
                <Switch
                  checked={notificationSettings.notifyOnDeviceOffline}
                  onChange={handleNotificationChange}
                  name="notifyOnDeviceOffline"
                  color="primary"
                />
              }
              label="إشعار عند انقطاع اتصال جهاز"
            />
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControlLabel
              control={
                <Switch
                  checked={notificationSettings.notifyOnApkBuild}
                  onChange={handleNotificationChange}
                  name="notifyOnApkBuild"
                  color="primary"
                />
              }
              label="إشعار عند اكتمال بناء تطبيق"
            />
          </Grid>
          
          <Grid item xs={12} md={6}>
            <FormControlLabel
              control={
                <Switch
                  checked={notificationSettings.dailyReportEnabled}
                  onChange={handleNotificationChange}
                  name="dailyReportEnabled"
                  color="primary"
                />
              }
              label="تمكين التقرير اليومي"
            />
          </Grid>
          
          {notificationSettings.dailyReportEnabled && (
            <Grid item xs={12} md={6}>
              <FormControl className={classes.formControl}>
                <TextField
                  label="وقت إرسال التقرير اليومي"
                  name="dailyReportTime"
                  type="time"
                  value={notificationSettings.dailyReportTime}
                  onChange={handleNotificationChange}
                  fullWidth
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </FormControl>
            </Grid>
          )}
        </Grid>
      </Paper>
      
      {/* أزرار الإجراءات */}
      <div className={classes.buttonContainer}>
        <Button
          variant="contained"
          color="default"
          startIcon={<RefreshIcon />}
          onClick={handleResetSettings}
          className={classes.button}
        >
          إعادة تعيين
        </Button>
        
        <Button
          variant="contained"
          color="primary"
          startIcon={<SaveIcon />}
          onClick={handleSaveSettings}
        >
          حفظ الإعدادات
        </Button>
      </div>
      
      {/* رسائل التنبيه */}
      <Snackbar open={snackbar.open} autoHideDuration={6000} onClose={handleCloseSnackbar}>
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default Settings;